<!DOCTYPE html>
<html>
<head>
    <title>EUA PORTAL</title>
    <meta charset='utf-8' />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Page Icon -->
    <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/img/logo.png" />
    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/accounts/signin.css">
    <!-- Java Script -->
    <script src="<?php echo base_url(); ?>assets/js/jquery-1.11.0.min.js"></script>
</head>

<body>
    <div id="header">
        <img id="logo" src="<?php echo base_url(); ?>assets/img/product-logo.png" alt="Evangel University Student Management System Software" />
        <span id="signup-button">
            <button id="signup" class="btn btn-danger">REGISTER</button>
        </span> <!-- #signup-button -->
    </div> <!-- #header -->
    <div id="content" class="row-fluid">
        <div id="introduction" class="span6">
            <img src="<?php echo base_url(); ?>assets/img/bg.png" />
        </div> <!-- #introduction -->
		
        <div id="signin-container" class="span6">
            <div id="signin-box">
                <h2>SIGNIN</h2>
                <form id="signin-form" action="<?php echo base_url(); ?>accounts/signin" method="post" accept-charset="utf-8">
                    <div id="username-div">
                        <label for="username"><strong>MATRIC NO./ STAFF ID</strong></label>
                        <input type="text" id="username" name="username" maxlength="16" 
                               value="<?php echo ( isset($username) ? $username : '' ); ?>" />
                        <?php 
                            if ( isset($is_username_empty) && $is_username_empty ) {
                                echo '<span id="errormsg_Username" class="errormsg">Please enter your MATRIC/ STAFF ID</span>';
                            }
                        ?>
                    </div> <!-- #username-div -->
                    <div id="password-div">
                        <label for="password"><strong>PASSWORD</strong></label>
                        <input type="password" id="password" name="password" maxlength="16" />
                        <?php 
                            $is_print = false;
                            if ( ( isset($is_password_empty) && $is_password_empty) ) {
                                $is_print = true;
                                echo '<span id="errormsg_Password" class="errormsg">Please enter your password</span>';
                            } 
                            if ( !$is_print && isset($is_password_correct) && !$is_password_correct ) {
                                echo '<span id="errormsg_Password" class="errormsg">Username or password is incorrect</span>';
                            }
                        ?>
                    </div> <!-- #password-div -->
                    <button  type="submit" class="btn btn-primary">GO!</button>
                    <label id="remember" class="checkbox">
                        <input id="persistent-cookie" name="persistent-cookie" type="checkbox" />
                        <label id="remember-label">REMEMBER ME</label>
                    </label>
                </form>
            </div> <!-- #signin-box -->
        </div> <!-- #signin-container -->
    </div> <!-- #content -->
    <?php
        require_once APPPATH.'views/common/footer.php';
    ?>
    <!-- Java Script -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script type="text/javascript">
        $(document).ready(function() {
            $(window).resize(function() {
                set_footer_position()
            });
        });
    </script> 
    <script type="text/javascript">
        function set_footer_position() {
            $('#footer').css('position', 'relative');
            if ( $(window).height() < $(document).height() ) {
                $('#footer').css('position', 'relative');
            } else {
                $('#footer').css('position', 'absolute');
            }
        }
    </script>
    <!-- Start of StatCounter Code for Default Guide -->
<script type="text/javascript">
var sc_project=11348767; 
var sc_invisible=1; 
var sc_security="50732d3c"; 
var scJsHost = (("https:" == document.location.protocol) ?
"https://secure." : "http://www.");
document.write("<sc"+"ript type='text/javascript' src='" +
scJsHost+
"statcounter.com/counter/counter.js'></"+"script>");
</script>
<noscript><div class="statcounter"><a title="web analytics"
href="http://statcounter.com/" target="_blank"><img
class="statcounter"
src="//c.statcounter.com/11348767/0/50732d3c/1/" alt="web
analytics"></a></div></noscript>
<!-- End of StatCounter Code for Default Guide -->
</body>
</html>
