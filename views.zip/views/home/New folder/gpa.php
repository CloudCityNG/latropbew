<div id="gpa-header" class="page-header">
	<h1>GPA Inquire</h1>
</div> <!-- /gpa-header -->
<div id="gpa-content" class="section">
	<p>
		<span><strong>Selected course total Grade Point Average:</strong></span>
		<span class="badge badge-info"><?php echo ( $gpa ? $gpa['total_grade_points'] : 0 ); ?></span>
	</p>
	<p>
		<span><strong>Total credits selected Courses:</strong></span>
		<span class="badge badge-info"><?php echo ( $gpa ? $gpa['total_credits'] : 0 ); ?></span>
	</p>
	<p>
		<span><strong>Selected courses GPA:</strong></span>
		<span class="badge badge-info"><?php echo ( $gpa ? $gpa['gpa'] : 0 ); ?></span>
	</p>
	<p>
		<span><strong>Your ranking in this year:</strong></span>
		<span class="badge badge-success"><?php echo ( $gpa ? $gpa['ranking'] : 0 ); ?></span>
	</p>
</div> <!-- /gpa-content -->
