<div id="transcripts-header" class="page-header">
    <h1>Registered Courses</h1>
</div> <!-- /transcripts-header -->
<div id="transcripts-content" class="section">
    <div id="selector">
        <select id="available-years" class="span2">
            <?php
                foreach ( $available_years as $available_year ) {
                    $year = $available_year['school_year'];
                    echo '<option value="'.$year.'">'.$year.'-'.($year + 1).' SESSION</option>';
                }
            ?>
        </select>
        <select id="available-semesters" class="span2">
            <option value="1">First semester</option>
            <option value="2">Second semester</option>
        </select>
    </div> <!-- /selector -->
	<div id="dvContainer">
    <div id="list">
        <table id="transcripts-records" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <td style="font-weight: bold;">Course code</td>
                    <td style="font-weight: bold;">Course Title</td>
                    <td style="font-weight: bold;">Course Lecturer</td>
                    <!--td style="font-weight: bold;">Examination</td>
                    <td style="font-weight: bold;">Ranking</td>
                    <td style="font-weight: bold;">Grade Point Average</td>
                    <td style="font-weight: bold;">Make-up results</td>-->
                    <td style="font-weight: bold;">Credit Unit&nbsp(s)&nbsp</td>
                </tr>
            </thead>
            <tbody></tbody>
						<thead>
                <tr>
                    <td style="font-weight: bold;">Course code</td>
                    <td style="font-weight: bold;">Course Title</td>
                    <td style="font-weight: bold;">Course Lecturer</td>
                    <!--td style="font-weight: bold;">Examination</td>
                    <td style="font-weight: bold;">Ranking</td>
                    <td style="font-weight: bold;">Grade Point Average</td>
                    <td style="font-weight: bold;">Make-up results</td>-->
                    <td style="font-weight: bold;">Credit Unit&nbsp(s)&nbsp</td>
                </tr>
            </thead>
        </table>
    </div> <!-- /list -->
	</div><!-- dvContainer-->
    <div id="page-error" class="alert alert-error hide"><strong>Alert: </strong>No Available data found.</div>
	<div id="page-error2" class="alert alert-error hide"><strong>Alert: </strong>Course Registration is closed.</div>
</div> <!-- /transcripts-content -->
<div class="section">
<button class="btn btn-success" id="btnPrint"><i class="glyphicon glyphicon-plus"></i> Print Registered Courses</button>
<!-- /print-content -->
<?php
$result = mysql_query("SELECT sum(credits) FROM stumgr_courses") or die(mysql_error());
while ($rows = mysql_fetch_array($result)){
	?>
	<button class="btn btn-success"><i class="glyphicon glyphicon-plus"></i>Total Credit Load: <?php echo $rows['sum(credits)']; ?></button>
	<!--div class="pull-right">
	<div class="span"><div class="alert alert-sccess"><i class="icon-credit-card icon-large"></i>&nbsp; Total: &nbsp;<?php echo $rows['sum(credits)']; ?></div>
	</div>-->
<?php }
?>
</div>

<script type="text/javascript">
  $('#available-years').change(function(){
        var school_year = $(this).val(),
            semester    = $('#available-semesters').val();
        get_transcripts_records(school_year, semester);
    });
    $('#available-semesters').change(function(){
        var school_year = $('#available-years').val(),
            semester    = $(this).val();
        get_transcripts_records(school_year, semester);
    });
</script>
<script type="text/javascript">
    function get_transcripts_records(school_year, semester) {
        $.ajax({
            type: 'GET',
            async: true,
            url: "<?php echo base_url().'home/get_transcripts_records7/'; ?>" + school_year + '/' + semester,
            dataType: 'JSON',
            success: function(result) {
                $('#transcripts-records tbody').empty();
                if ( result['is_successful'] ) {
                    var total_records = result['records'].length;
                    for ( var i = 0; i < total_records; ++ i ) {
                        $('#transcripts-records').append(
                            '<tr class="table-datum">' + 
                            '<td>' + result['records'][i]['course_id'] + '</td>' + 
                            '<td>' + result['records'][i]['course_name'] + '</td>' + 
                            '<td>' + result['records'][i]['staff_name'] + '</td>' +
							//'<td>' + result['records'][i]['paper_score'] + '</td>' + 
                            //'<td>' + result['records'][i]['final_score'] + '</td>' + 
                           // '<td>' + result['records'][i]['ranking'] + '/' + result['records'][i]['total'] + '</td>' + 
                            //'<td>' + result['records'][i]['grade_point'] + '</td>' + 
                            //'<td>' + result['records'][i]['is_passed'] + '</td>' + 
                            '<td>' + result['records'][i]['credits'] + '</td>' + 
                            '</tr>'
                        );
                    }
                    set_visible('#page-error', false);
					set_visible('#page-error2', false);
                    set_visible('#list', true);
                } else {
                    set_visible('#page-error', true);
					set_visible('#page-error2', true);
                    set_visible('#list', false);
                }
            }
        });
    }
</script>
<script type="text/javascript">
    function set_visible(element, is_visible) {
        if ( is_visible ) {
            $(element).css('display', 'block');
        } else {
            $(element).css('display', 'none');
        }
        set_footer_position();  // which is defined in index.php
    }
</script>
<script type="text/javascript">
    $(document).ready(function(){
        var school_year = $('#available-years').val(),
            semester    = $('#available-semesters').val();
        get_transcripts_records(school_year, semester);
    })
</script>