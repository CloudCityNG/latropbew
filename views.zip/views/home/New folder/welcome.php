<div id="welcome-center-header" class="page-header">
	<h1>welcome</h1>
</div> <!-- /welcome-center-header -->
<div id="welcome-center-section" class="section">
	<p><strong><?php echo $welcome['display_name']; ?></strong>Students Hello, Welcome to College Student Management System Software.</p>
	<p>Your IP address: <strong><?php echo $welcome['ip_address']; ?></strong>.</p>
	<p><?php
		if ( $welcome['last_time_signin'] == '0000-00-00 00:00:00' ) {
			echo 'This is the first time you use the system, You can click<a href="'.base_url().'home#profile">Here </a> change your password.';	
		} else {
			$time = strtotime($welcome['last_time_signin']);
			echo 'Last access time: <strong>'.date('Y|m|d H:i',$time).'</strong>';
		}
	?></p>
</div> <!-- /welcome-center-section -->

<div id="accounts-header" class="page-header">
	<h1> Basic Information</h1>
</div> <!-- /accounts-header -->
<div id="accounts-section" class="section">
	<table class="table" style="width: 84%;">
		<tr>
			<td><strong>student ID:</strong></td><td><?php echo $profile['student_id'] ?></td>
			<td><strong> Names:</strong></td><td><?php echo $profile['student_name'] ?></td>
		</tr>
		<tr>
			<td><strong>Year of Admission:</strong></td><td><?php echo $profile['grade']?></td>
			<td><strong>Hostel:</strong></td><td><?php echo $profile['room'] ?></td>
		</tr>
	</table>
</div> <!-- /accounts-section -->