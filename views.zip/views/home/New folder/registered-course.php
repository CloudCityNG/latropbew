<div id="transcripts-header" class="page-header">
    <h1>Result inquiry</h1>
</div> <!-- /transcripts-header -->
<div id="transcripts-content" class="section">
    <div id="selector">
        <select id="available-years" class="span2">
            <?php
                foreach ( $available_years as $available_year ) {
                    $year = $available_year['school_year'];
                    echo '<option value="'.$year.'">'.$year.'-'.($year + 1).' SESSION</option>';
                }
            ?>
        </select>
        <select id="available-semesters" class="span2">
            <option value="1">First semester</option>
            <option value="2">Second semester</option>
        </select>
    </div> <!-- /selector -->
    <div id="list">
        <table id="course-records" class="table table-striped">
            <thead>
                <tr>
                    <td>course code</td>
                    <td>Course Title</td>
                    <td>Continuous Assessment</td>
                    <td>Examination</td>
                    <td>Ranking</td>
                    <td>Grade Point Average</td>
                    <td>Make-up results</td>
                    <td>credit</td>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div> <!-- /list -->
    <div id="page-error" class="alert alert-error hide"><strong>Tips: </strong>Available data found.</div>
</div> <!-- /transcripts-content -->

<?php
$result = mysql_query("SELECT sum(credits) FROM stumgr_courses") or die(mysql_error());
while ($rows = mysql_fetch_array($result)){
	?>
	<div class="pull-right">
	<div class="span"><div class="alert alert-sccess"><i class="icon-credit-card icon-large"></i>&nbsp; Total: &nbsp;<?php echo $rows['sum(credits)']; ?></div>
	</div>
<?php }
?>

<script type="text/javascript">
    $('#available-years').change(function(){
        var school_year = $(this).val(),
            semester    = $('#available-semesters').val();
        get_course_records(school_year, semester);
    });
    $('#available-semesters').change(function(){
        var school_year = $('#available-years').val(),
            semester    = $(this).val();
        get_course_records(school_year, semester);
    });
</script>
<script type="text/javascript">
    function get_course_records(school_year, semester) {
        $.ajax({
            type: 'GET',
            async: true,
            url: "<?php echo base_url().'home/get_course_records/'; ?>" + school_year + '/' + semester,
            dataType: 'JSON',
            success: function(result) {
                $('#course-records tbody').empty();
                if ( result['is_successful'] ) {
                    var total_records = result['records'].length;
                    for ( var i = 0; i < total_records; ++ i ) {
                        $('#course-records').append(
                            '<tr class="table-datum">' + 
                            '<td>' + result['records'][i]['course_id'] + '</td>' + 
                            '<td>' + result['records'][i]['course_name'] + '</td>' + 
                            '<td>' + result['records'][i]['paper_score'] + '</td>' + 
                            '<td>' + result['records'][i]['final_score'] + '</td>' + 
                            '<td>' + result['records'][i]['ranking'] + '/' + result['records'][i]['total'] + '</td>' + 
                            '<td>' + result['records'][i]['grade_point'] + '</td>' + 
                            '<td>' + result['records'][i]['is_passed'] + '</td>' + 
                            '<td>' + result['records'][i]['credits'] + '</td>' + 
                            '</tr>'
                        );
                    }
                    set_visible('#page-error', false);
                    set_visible('#list', true);
                } else {
                    set_visible('#page-error', true);
                    set_visible('#list', false);
                }
            }
        });
    }
</script>
<script type="text/javascript">
    function set_visible(element, is_visible) {
        if ( is_visible ) {
            $(element).css('display', 'block');
        } else {
            $(element).css('display', 'none');
        }
        set_footer_position();  // which is defined in index.php
    }
</script>
<script type="text/javascript">
    $(document).ready(function(){
        var school_year = $('#available-years').val(),
            semester    = $('#available-semesters').val();
        get_course_records(school_year, semester);
    })
</script>