<div id="printArea">
<div id="transcripts-header" class="page-header">
    <h1>Registered Courses</h1>
</div> <!-- /transcripts-header -->
<div id="transcripts-content" class="section">
    <div id="selector">
        <select id="available-years" class="span2">
            <?php
                foreach ( $available_years as $available_year ) {
                    $year = $available_year['school_year'];
                    echo '<option value="'.$year.'">'.$year.'-'.($year + 1).' SESSION</option>';
                }
            ?>
        </select>
        <select id="available-semesters" class="span2">
            <option value="1">First semester</option>
            <option value="2">Second semester</option>
        </select>
    </div> <!-- /selector -->
	<p>
	<a href="#registered" class="btn btn-warning" role="button">WORD</a>  
	<a href="#registered" class="btn btn-default" role="button">PDF</a>  
	<a href="#registered" class="btn btn-success" role="button">EXCEL</a> 
	<a href="#registered" onclick="javascript:printDiv('printArea')" id="btnPrint" class="btn btn-success" role="button">PRINT</a> 
    </p>
	<div id="dvContainer">
    <div id="list">
        <table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%">
      <thead>
        <tr>
					<th>Course Code</th>
					<th>Course Title</th>
					<th>Credit Unit</th>
					<th>Level</th>
					<th>Programme</th>
					<th>Semester</th>
					<th>Lecturer Name</th>
					<th>Staff ID</th>

          <th style="width:125px;">Action
          </p></th>
        </tr>
      </thead>
      <tbody>
				<?php foreach($books as $book){?>
				     <tr>
				         <td><?php echo $book->course_id;?></td>
				         <td><?php echo $book->course_name;?></td>
								 <td><?php echo $book->credit_unit;?></td>
								 <td><?php echo $book->level;?></td>
								<td><?php echo $book->programme;?></td>
								<td><?php echo $book->semester;?></td>
								<td><?php echo $book->staff_name;?></td>
								<td><?php echo $book->username;?></td>
								<td>
									<button class="btn btn-warning" onclick="edit_book(<?php echo $book->id;?>)"><i class="glyphicon glyphicon-pencil"></i></button>
									<button class="btn btn-danger" onclick="delete_book(<?php echo $book->id;?>)"><i class="glyphicon glyphicon-remove"></i></button>


								</td>
				      </tr>
				     <?php }?>



      </tbody>

      <tfoot>
        <tr>
          <th>Course Code</th>
		  <th>Course Title</th>
		  <th>Credit Unit</th>
		  <th>Level</th>
		  <th>Programme</th>
		  <th>Semester</th>
		  <th>Lecturer Name</th>
		  <th>Staff ID</th>
          <th>Action</th>
        </tr>
      </tfoot>
    </table>
    </div> <!-- /list -->
	</div><!-- dvContainer-->
    <div id="page-error" class="alert alert-error hide"><strong>Alert: </strong>No Available data found.</div>
	<div id="page-error2" class="alert alert-error hide"><strong>Alert: </strong>Course Registration is closed.</div>
</div> <!-- /transcripts-content -->

<script src="<?php echo base_url('assests/jquery/jquery-3.1.0.min.js')?>"></script>
  <script src="<?php echo base_url('assests/bootstrap/js/bootstrap.min.js')?>"></script>
  <script src="<?php echo base_url('assests/datatables/js/jquery.dataTables.min.js')?>"></script>
  <script src="<?php echo base_url('assests/datatables/js/dataTables.bootstrap.js')?>"></script>
  <script type="text/javascript">
  $(document).ready( function () {
      $('#table_id').DataTable();
  } );
    var save_method; //for save method string
    var table;


    function add_book()
    {
      save_method = 'add';
      $('#form')[0].reset(); // reset form on modals
      $('#modal_form').modal('show'); // show bootstrap modal
    //$('.modal-title').text('Add Person'); // Set Title to Bootstrap modal title
    }

    function edit_book(id)
    {
      save_method = 'update';
      $('#form')[0].reset(); // reset form on modals

      //Ajax Load data from ajax
      $.ajax({
        url : "<?php echo site_url('home/ajax_edit/')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="course_id"]').val(data.course_id);
            $('[name="course_title"]').val(data.course_title);
            $('[name="credit_unit"]').val(data.credit_unit);
            $('[name="level"]').val(data.level);
            $('[name="programme"]').val(data.programme);
            $('[name="semester"]').val(data.semester);
            $('[name="lecturer_name"]').val(data.lecturer_name);
            $('[name="username"]').val(data.username);


            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit Book'); // Set title to Bootstrap modal title

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
    }



    function save()
    {
      var url;
      if(save_method == 'add')
      {
          url = "<?php echo site_url('home/book_add')?>";
      }
      else
      {
        url = "<?php echo site_url('home/book_update')?>";
      }

       // ajax adding data to database
          $.ajax({
            url : url,
            type: "POST",
            data: $('#form').serialize(),
            dataType: "JSON",
            success: function(data)
            {
               //if success close modal and reload ajax table
               $('#modal_form').modal('hide');
              location.reload();// for reload a page
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Added / Updated Data Successfully');
            }
        });
    }

    function delete_book(id)
    {
      if(confirm('Are you sure delete this data?'))
      {
        // ajax delete data from database
          $.ajax({
            url : "<?php echo site_url('home/book_delete')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
               
               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });

      }
    }

  </script>




<script type="text/javascript">
    function set_visible(element, is_visible) {
        if ( is_visible ) {
            $(element).css('display', 'block');
        } else {
            $(element).css('display', 'none');
        }
        set_footer_position();  // which is defined in index.php
    }
</script>
