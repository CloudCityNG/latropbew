<div id="peer-assessment-header" class="page-header">
	<h1>Student peer assessment</h1>
</div> <!-- /peer-assessment-header -->
<div id="peer-assessment-content" class="section">
	<?php
		if ( !$options['is_peer_assessment_active'] ) {
			echo '<div class="alert alert-error"><strong>Tips: </strong>Student peer assessment system is off</div>';
		} else if ( $extra['is_participated'] ) {
			echo '<div class="alert alert-success"><strong>Tips: </strong>You have successfully completed evaluation</div>';
		} else {
			require_once(APPPATH.'views/home/assessment-content.php');
		}
	?>
</div> <!-- /peer-assessment-content -->