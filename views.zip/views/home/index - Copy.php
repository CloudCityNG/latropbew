<!DOCTYPE html>
<html>
<head>
	<title>Evangel University Management System </title>
	<meta charset='utf-8' />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Page Icon -->
	<link rel="shortcut icon" href="<?php echo base_url(); ?>assets/img/logo.png" />
	<!-- CSS -->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/home/site.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-responsive.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/home/style.css">
	<!-- Java Script -->
	<script src="<?php echo base_url(); ?>assets/js/jquery-1.11.0.min.js"></script>
</head>

<body>
	<div id="container">
		<div id="header">
			<?php
				require_once APPPATH.'views/common/header-for-users.php';
			?>
		</div> <!-- /header -->
		<div id="content">
			<div id="sidebar">
			<a class="sidebar-collapse" id="sidebar-collapse" data-toggle="collapse" data-target="#test">
										<i id="icon-sw-s-b" class="fa fa-angle-double-left"></i>
									</a>

				<div id="sidebar-nav-frame-welcome" class="sidebar-nav">
					<a href="#welcome"><div id="sidebar-nav-welcome" class="sidebar-primary-nav">welcome</div></a>
				</div>
				<!--div id="sidebar-nav-frame-routine" class="sidebar-nav">
					<a href="javascript:void(0)"><div id="sidebar-nav-routine" class="sidebar-primary-nav">Weekly routine</div></a>
					<a href="#attendance"><div id="sidebar-nav-attendance" class="sidebar-secondary-nav">Attendance</div></a>
					<a href="#hygiene"><div id="sidebar-nav-hygiene" class="sidebar-secondary-nav">Health situation</div></a>
				</div>-->
				<div id="sidebar-nav-frame-evaluation" class="sidebar-nav">
					<a href="javascript:void(0)"><div id="sidebar-nav-registration" class="sidebar-primary-nav">Course Registration</div></a>
					<!--a href="#crud"><div id="sidebar-nav-crud" class="sidebar-secondary-nav">CRUD Operation</div></a>-->
					<a href="#coursereg"><div id="sidebar-nav-coursereg" class="sidebar-secondary-nav">Register Courses</div></a>
					<a href="#regplatform"><div id="sidebar-nav-regplatform" class="sidebar-secondary-nav">Registration Platform</div></a>
					<a href="#registered"><div id="sidebar-nav-registered" class="sidebar-secondary-nav">View Registered Courses</div></a>
				</div>
				<div id="sidebar-nav-frame-scores" class="sidebar-nav">
					<a href="javascript:void(0)"><div id="sidebar-nav-scores" class="sidebar-primary-nav">Result inquiry</div></a>
					<a href="#transcripts"><div id="sidebar-nav-transcripts" class="sidebar-secondary-nav">Result inquiry</div></a>
					<a href="#gpa"><div id="sidebar-nav-gpa" class="sidebar-secondary-nav">CGPA Inquire</div></a>
				</div>
		
				<div id="sidebar-nav-frame-evaluation" class="sidebar-nav">
					<a href="javascript:void(0)"><div id="sidebar-nav-evaluation" class="sidebar-primary-nav">Administration</div></a>
					<a href="#feespayment"><div id="sidebar-nav-feespayment" class="sidebar-secondary-nav">School Fees Payment</div></a>
					<a href="#payment"><div id="sidebar-nav-payment" class="sidebar-secondary-nav">Payment Status</div></a>
				</div>
			</div> <!-- /sidebar -->
			<div id="loading">loading...</div>
			<div id="shadow"></div>
			<div id="main-container">
				<noscript>
					<p>Your browser does not support JavaScript or JavaScript terminated.</p>
					<p>Since your browser does not support JavaScript Or has been disabled JavaScript, Therefore, we can not display the requested page.</p>
				</noscript>
				<div id="main-content">
				</div> <!-- /main-content -->
				<?php
					require_once APPPATH.'views/common/footer.php';
				?>
			</div> <!-- /main-content -->
		</div> <!-- /content -->
	</div> <!-- /container -->
	<!-- Java Script -->
	<!-- Placed at the end of the document so the pages load faster -->
	<script type="text/javascript">
		$(document).ready(function() {
			$(window).resize(function() {
				set_footer_position();
			});
			$('#main-container').scroll(function() {
				if ( $('#main-content').position().top < 0 ) {
					$('#shadow').css('opacity', 1);
				} else {
					$('#shadow').css('opacity', 0);
				}
			});
		});
	</script> 
	<script type="text/javascript">
		$(document).ready(function() {
			var page_name = window.location.href.match(/#.*$/);
			if ( page_name == null ) {
				load('welcome');
			} else {
				load(window.location.href.match(/#.*$/)[0].substr(1));
			}
		});
	</script> 
	<script type="text/javascript">
		if ( ("onhashchange" in window) && !navigator.userAgent.toLowerCase().match(/msie/) ) {
			$(window).on('hashchange', function() {
				set_loading_block(true, true);
				load(window.location.href.match(/#.*$/)[0].substr(1));
			});
		} else {
			var prevHash = window.location.hash;
	        window.setInterval(function () {
	           if (window.location.hash != prevHash) {
	              prevHash = window.location.hash;
	              set_loading_block(true, true);
	              load(window.location.href.match(/#.*$/)[0].substr(1));
	           }
	        }, 100);
		}
	</script>
	<script type="text/javascript">
		function load(page){
			$('.active').removeClass('active');
			var sidebar_nav = $('#sidebar-nav-' + page);
			sidebar_nav.addClass('active');
			sidebar_nav.closest('.sidebar-nav').children().children('.sidebar-secondary-nav').slideDown(0);
			$.ajax( {
				type: 'GET',
				url: "<?php echo base_url(); ?>" + 'home/load/' + page,
				cache: false,
				async: false,
				error: function() {
					set_loading_block(false, true);
				}, // End of error function of ajax form
				success: function(html_content) {
					if ( html_content != '' ) {
						$("#main-content").html(html_content);
						set_loading_block(true, false);
					} else {
						set_loading_block(false, true);
					}
					set_footer_position();
				} // End of success function of ajax form
			}); // End of ajax call
		}
	</script>
	<script type="text/javascript">
		function set_loading_block(is_success, is_visible) {
			if ( is_success ) {
				$('#loading').removeClass('error');
				$('#loading').addClass('loading');
				$('#loading').html('loading...');
			} else {
				$('#loading').removeClass('loading');
				$('#loading').addClass('error');
				$("#main-content").html('');
				var page = window.location.href.match(/#.*$/)[0].substr(1);
				$('#loading').html('An unknown error occurred <a href="#' + page + 
									'" onclick="javascript:set_loading_block(' + true + ', ' + true + '); ' + 
									'javascript:load(\'' + page + '\');' + ' return false;">Retry</a>');
			}

			if ( is_visible ) {
				$('#loading').fadeIn();
			} else {
				$('#loading').css('display', 'none');
			}
		}
	</script>
	<script type="text/javascript">
		function set_footer_position() {
			$('#footer').css('position', 'relative');
			if ( $('#footer').position().top + 144 < $(document).height() ) {
				$('#footer').css('position', 'absolute');
			} else {
				$('#footer').css('position', 'relative');
			}
		}
	</script>
	<script type="text/javascript">
		$('.sidebar-primary-nav').click(function() {
			var secondary_nav_items = $(this).closest('.sidebar-nav').children().children('.sidebar-secondary-nav');
			if ( secondary_nav_items.is(':visible') ) {
				secondary_nav_items.slideUp(120);
			} else {
				secondary_nav_items.slideDown(120);
			}
		});
	</script>
</body>
</html>
