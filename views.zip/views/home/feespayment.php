<div class="col-md-8">
                        <div class="pricing">
                          <ul>
                            <li class="unit price-primary">
                                              <div class="price-title">
                                                <h2>$135,000</h2>
                                                <p>First Semester</p>
                                              </div>
                                              <div class="price-body">
                                                <h4>Basic</h4>
                                                <p>Lots of clients &amp; users</p>
                                                <ul>
                                                  <li>250 SKU's</li>
                            <li>1 GB Storage</li>
                            <li>3,5% transaction fee</li>
                          </ul>
                        </div>
                        <div class="price-foot">
                          <button type="button" class="btn btn-primary">Pay Now</button>
                        </div>
                        </li>
                        <p>
                        <li class="unit price-primary">
                                              <div class="price-title">
                                                <h4>$115,000</h4>
                                                <p>Second Semester</p>
                                              </div>
                                              <div class="price-body">
                                                <h4>Premium</h4>
                                                <p>Lots of clients &amp; users</p>
                                                <ul>
                                                  <li>2500 SKU's</li>
                        <li>5 GB Storage</li>
                        <li>1,5% transaction fee</li>
                        </ul>
                      </div>
                      <div class="price-foot">
                        <button type="button" class="btn btn-success">Pay Now</button>
                      </div>
                      </li>
                      
                    </ul>
                  </div>
                </div>