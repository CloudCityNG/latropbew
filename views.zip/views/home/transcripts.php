

<div id="transcripts-header" class="page-header">
    <h1>Result inquiry</h1>
</div> <!-- /transcripts-header -->
<div id="transcripts-content" class="section">
    <div id="selector">
        <select id="available-years" class="span3">
            <?php
                foreach ( $available_years as $available_year ) {
                    $year = $available_year['school_year'];
                    echo '<option value="'.$year.'">'.$year.'-'.($year + 1).'Academic Year</option>';
                }
            ?>
        </select>
        <select id="available-semesters" class="span2">
            <option value="1">First semester</option>
            <option value="2">Second Semester</option>
        </select>
        <p>
        <div class="alert alert-info alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <strong>Alert!</strong> QP: Quality Point | CU: Credit Units | GPA: Grade Point Average | TQP: Total Quality Point | TCU: Total Credit Units | CGPA: Cummulative Grade Point Average.
        </div>
		<span><strong>CURRENT SEMESTER:</strong></span>
		<!--br>
		<span><strong>QP:</strong></span>
        <span class="badge badge-info"><?php echo ( $gpa ? $gpa['total_grade_points'] : 0 ); ?></span>
        <span><strong>CU:</strong></span>
        <span class="badge badge-info"><?php echo ( $gpa ? $gpa['total_credits'] : 0 ); ?></span>
		<span><strong>GPA:</strong></span>
        <span class="badge badge-success"><?php echo ( $gpa ? $gpa['gpa'] : 0 ); ?></span>
		
		<br><hr>-->
		<span><strong>CUMMULATIVE:</strong></span>
		<br>
		<span><strong>TQP:</strong></span>
        <span class="badge badge-info"><?php echo ( $gpa ? $gpa['total_grade_points'] : 0 ); ?></span>
        <!--span><strong>Your ranking in this year:</strong></span>
        <span class="badge badge-success"><?php echo ( $gpa ? $gpa['ranking'] : 0 ); ?></span>-->
        <span><strong>TCU:</strong></span>
        <span class="badge badge-info"><?php echo ( $gpa ? $gpa['total_credits'] : 0 ); ?></span>
        <span><strong>CGPA:</strong></span>
        <span class="badge badge-success"><?php echo ( $gpa ? $gpa['gpa'] : 0 ); ?></span>
    </p>
    </div> <!-- /selector -->
    <div id="list" onload="finishTable();">
        <table id="transcripts-records" class="table table-striped">
            <thead>
                <tr>
                    <td>Course Code</td>
                    <td>Course Title</td>
                    <td>C/A</td>
                    <td>Examination</td>
					<td>Total Score</td>
					<td>Status</td>
                    <!--td>Ranking</td>-->
                    <td data-field="grade">Point</td>
                    <!--td>Grade</td>-->
                    <!--td>Make-up results</td>-->
                    <td data-field="credits">Credit Units</td>
					
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div> <!-- /list -->
    <div id="page-error" class="alert alert-error hide"><strong>Alert: </strong>No Available data found.Result not computed for the semester</div>
</div> <!-- /transcripts-content -->
<!--
<!--?php
$result = mysql_query("SELECT sum(credits) FROM stumgr_courses") or die(mysql_error());
while ($rows = mysql_fetch_array($result)){
	?>
	<div class="pull-right">
	<div class="span"><div class="alert alert-sccess"><i class="icon-credit-card icon-large"></i>&nbsp; Total: &nbsp;<?php echo $rows['sum(credits)']; ?></div>
	</div>
<!--?php }
?>-->


<script type="text/javascript">
    $('#available-years').change(function(){
        var school_year = $(this).val(),
            semester    = $('#available-semesters').val();
        get_transcripts_records(school_year, semester);
    });
    $('#available-semesters').change(function(){
        var school_year = $('#available-years').val(),
            semester    = $(this).val();
        get_transcripts_records(school_year, semester);
    });
</script>
<script type="text/javascript">
    function get_transcripts_records(school_year, semester) {
        $.ajax({
            type: 'GET',
            async: true,
            url: "<?php echo base_url().'home/get_transcripts_records/'; ?>" + school_year + '/' + semester,
            dataType: 'JSON',
            success: function(result) {
                $('#transcripts-records tbody').empty();
                if ( result['is_successful'] ) {
                    var total_records = result['records'].length;
                    for ( var i = 0; i < total_records; ++ i ) {
                        $('#transcripts-records').append(
                            '<tr class="table-datum">' + 
                            '<td>' + result['records'][i]['course_id'] + '</td>' + 
                            '<td>' + result['records'][i]['course_name'] + '</td>' + 
                            '<td>' + result['records'][i]['paper_score'] + '</td>' + //continuous assessment
                            '<td>' + result['records'][i]['final_score'] + '</td>' + //examination
							'<td>' + (parseFloat(result['records'][i]['paper_score']) + parseFloat(result['records'][i]['final_score'])) + '</td>' + //ca + exam
							
							'<td>' + result['records'][i]['is_passed'] + '</td>' + 
                            //'<td>' + result['records'][i]['ranking'] + '/' + result['records'][i]['total'] + '</td>' + 
                            '<td class="grade">' + result['records'][i]['grade_point'] + '</td>' + 
                            //'<td>' + result['records'][i]['paper_grade'] + '</td>' + 
                            //'<td>' + result['records'][i]['is_passed'] + '</td>' + 
                            '<td class="credit">' + result['records'][i]['credits'] + '</td>' + 
                            
							'</tr>'
                        );
                    }
                    set_visible('#page-error', false);
                    set_visible('#list', true);
                } else {
                    set_visible('#page-error', true);
                    set_visible('#list', false);
                }
            }
        });
    }
</script>
<script type="text/javascript">
    function set_visible(element, is_visible) {
        if ( is_visible ) {
            $(element).css('display', 'block');
        } else {
            $(element).css('display', 'none');
        }
        set_footer_position();  // which is defined in index.php
    }
</script>
<script type="text/javascript">
    $(document).ready(function(){
        var school_year = $('#available-years').val(),
            semester    = $('#available-semesters').val();
        get_transcripts_records(school_year, semester);
    })
</script>