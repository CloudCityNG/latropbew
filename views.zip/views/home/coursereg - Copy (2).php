<div id="rewards-header" class="page-header">
	<h1>Course Registration</h1>
</div> <!-- /rewards-header -->
<div id="rewards-content" class="section">
    <div id="rewards-content-header" style="overflow: auto;">
        <div id="selector" style="float: left;">
            <select id="available-years" class="span2">
                <?php
                    foreach ( $available_years as $available_year ) {
                        $year = $available_year['school_year'];
                        echo '<option value="'.$year.'">'.$year.'-'.($year + 1).' Academic Session</option>';
                    }
                ?>
            </select>
            <select id="available-semesters" class="span2">
            <option value="1">First semester</option>
            <option value="2">Second semester</option>
        </select>
        </div> <!-- /selector -->
	</div>
		<hr>
      <div>
	  <select class="selecter_1 selecter-element" name="meal" id="meal" onChange="changecat(this.value);">
    <option value="" disabled selected>Select College</option>
    <option value="SC">College Of Science</option>
    <option value="MGT">College Of Mgt. Sc.</option>
    <!--option value="C">C</option>-->
	<!--option value="D">College of Art</option>-->
</select>
<select name="category" id="category">
    <option value="" disabled selected>Select Programme</option>
</select>
	  </div>
</div>			
<script type="text/javascript">
var mealsByCategory = {
  SC: ["Mathematics", "Physics", "Biology", "Biochemistry", "Chemistry", "Microbiology"],
  MGT: ["Banking And Finance", "Management", "Marketing", "Accounting"],
 // C: ["Soup", "Juice", "Coffee", "Tea", "Others"]
  //D: ["Mathematics", "Physics", "Biology", "Biochemistry", "Chemistry"]
}

function changecat(value) {
  if (value.length == 0) document.getElementById("category").innerHTML = "<option></option>";
  else {
    var catOptions = "";
    for (categoryId in mealsByCategory[value]) {
      catOptions += "<option>" + mealsByCategory[value][categoryId] + "</option>";
    }
    document.getElementById("category").innerHTML = catOptions;
  }
}

</script>
