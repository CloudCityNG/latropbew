<link rel="stylesheet" media="screen" href="<?php echo base_url(); ?>assets/css/home/messenger.css">
<link rel="stylesheet" media="screen" href="<?php echo base_url(); ?>assets/css/home/messenger-theme-future.css">

<div class="alert alert-info">
    <?php
        $number_of_students = count($students);
        $min_number_of_excellent_students = floor($number_of_students * $options['min_excellent_percents']);
        $max_number_of_excellent_students = floor($number_of_students * $options['max_excellent_percents']);
        $min_number_of_good_students      = floor($number_of_students * $options['min_good_percents']);
        $max_number_of_good_students      = floor($number_of_students * $options['max_good_percents']);
        $min_number_of_medium_students    = floor($number_of_students * $options['min_medium_percents']);
        $max_number_of_medium_students    = floor($number_of_students * $options['max_medium_percents']);
    ?>
    <strong>Tips: </strong>
    <?php echo $extra['student_name']; ?>Students Hello and welcome to Evangel University Akaeze<?php echo $school_year ?>~<?php echo ($school_year + 1) ?>Year comprehensive evaluation.<br />
    Your class is<?php echo $extra['grade']; ?>level<?php echo $extra['class']; ?>Classes, a total student<?php echo $number_of_students ?>people.<br />
    Therefore, the number should be excellent<?php echo $min_number_of_excellent_students.'~'.$max_number_of_excellent_students; ?>Between people,
            The number should be in good<?php echo $min_number_of_good_students.'~'.$max_number_of_good_students; ?>Between people,
            The difference in the number of people should be<?php echo $min_number_of_medium_students.'~'.$max_number_of_medium_students; ?>Between people.<br />
    Wherein the fine corresponding to the difference in value, respectively<?php echo $options['excellent_score'].'Minute, '.$options['good_score'].'Minute, '.$options['medium_score'].'Minute, '.$options['poor_score'].'Minute.'; ?>

</div>
<table class="table table-striped">
    <thead>
        <tr>
            <td rowspan="2">student ID</td>
            <td rowspan="2">Full name</td>
            <td colspan="4" class="left-border text-center">moral(<?php echo $options['moral_percents'] * 100 ?>%)</td>
            <td colspan="4" class="left-border text-center">physical education(<?php echo $options['strength_percents'] * 100 ?>%)</td>
            <td colspan="4" class="left-border text-center">ability(<?php echo $options['ability_percents'] * 100 ?>%)</td>
        </tr>
        <tr>
            <td class="left-border">excellent</td>
            <td>good</td>
            <td>in</td>
            <td>difference</td>
            <td class="left-border">excellent</td>
            <td>good</td>
            <td>in</td>
            <td>difference</td>
            <td class="left-border">excellent</td>
            <td>good</td>
            <td>in</td>
            <td>difference</td>
        </tr>
    </thead>
    <tbody>
        <?php
            foreach ( $students as $student ) {
                if ( $student['student_id'] == $extra['student_id'] ) {
                    continue;
                }
                echo '<tr>';
                echo '<td>'.$student['student_id'].'</td>';
                echo '<td>'.$student['student_name'].'</td>';
                echo '<td class="left-border"><input type="radio" name="moral-'.$student['student_id'].'" class="moral excellent" value="excellent" /></td>';
                echo '<td><input type="radio" name="moral-'.$student['student_id'].'" class="moral good" value="good" checked /></td>';
                echo '<td><input type="radio" name="moral-'.$student['student_id'].'" class="moral medium" value="medium" /></td>';
                echo '<td><input type="radio" name="moral-'.$student['student_id'].'" class="moral poor" value="poor" /></td>';
                echo '<td class="left-border"><input type="radio" name="strength-'.$student['student_id'].'" class="strength excellent" value="excellent" /></td>';
                echo '<td><input type="radio" name="strength-'.$student['student_id'].'" class="strength good" value="good" checked /></td>';
                echo '<td><input type="radio" name="strength-'.$student['student_id'].'" class="strength medium" value="medium" /></td>';
                echo '<td><input type="radio" name="strength-'.$student['student_id'].'" class="strength poor" value="poor" /></td>';
                echo '<td class="left-border"><input type="radio" name="ability-'.$student['student_id'].'" class="ability excellent" value="excellent" /></td>';
                echo '<td><input type="radio" name="ability-'.$student['student_id'].'" class="ability good" value="good" checked /></td>';
                echo '<td><input type="radio" name="ability-'.$student['student_id'].'" class="ability medium" value="medium" /></td>';
                echo '<td><input type="radio" name="ability-'.$student['student_id'].'" class="ability poor" value="poor" /></td>';
                echo '</tr>';
            }
        ?>
    </tbody>
</table>
<button id="submit" class="btn btn-primary" onclick="javascript:post_votes_request();" disabled="disabled">submit</button>
<button class="btn btn-cancel" onclick="javascript:reset_options();">Reset</button>

<script src="<?php echo base_url(); ?>assets/js/messenger.min.js"></script> 
<script type="text/javascript">
    $._messengerDefaults = {
        extraClasses: 'messenger-fixed messenger-theme-future messenger-on-bottom messenger-on-right'
    }
    $('input[type="radio"]').click(function(){
        var votes    = get_votes_statistics();
        var is_legal = is_all_proportion_legal(votes.moral_votes, votes.strength_votes, votes.ability_votes);
        show_current_votes(votes.moral_votes, votes.strength_votes, votes.ability_votes, is_legal);

        if ( is_legal ) {
            $('#submit').removeAttr("disabled");
        } else {
            $('#submit').attr("disabled", "disabled");
        }
    });
</script>
<script type="text/javascript">
    function get_votes_statistics() {
        var moral_votes    = new Array(4),
            strength_votes = new Array(4),
            ability_votes  = new Array(4);
        moral_votes[0]    = $('.moral.excellent:checked').length;       moral_votes[1] = $('.moral.good:checked').length;
        moral_votes[2]    = $('.moral.medium:checked').length;          moral_votes[3] = $('.moral.poor:checked').length;
        strength_votes[0] = $('.strength.excellent:checked').length;    strength_votes[1] = $('.strength.good:checked').length;
        strength_votes[2] = $('.strength.medium:checked').length;       strength_votes[3] = $('.strength.poor:checked').length;
        ability_votes[0]  = $('.ability.excellent:checked').length;     ability_votes[1] = $('.ability.good:checked').length;
        ability_votes[2]  = $('.ability.medium:checked').length;        ability_votes[3] = $('.ability.poor:checked').length;

        return { moral_votes: moral_votes, strength_votes: strength_votes, ability_votes: ability_votes };
    }
</script>
<script type="text/javascript">
    function is_all_proportion_legal(moral_votes, strength_votes, ability_votes) {
        var min_number_of_excellent_students = <?php echo $min_number_of_excellent_students; ?>,
            max_number_of_excellent_students = <?php echo $max_number_of_excellent_students; ?>,
            min_number_of_good_students      = <?php echo $min_number_of_good_students; ?>,
            max_number_of_good_students      = <?php echo $max_number_of_good_students; ?>,
            min_number_of_medium_students    = <?php echo $min_number_of_medium_students; ?>,
            max_number_of_medium_students    = <?php echo $max_number_of_medium_students; ?>;
        var is_proportion_legal = true;
        if ( !(moral_votes[0]    >= min_number_of_excellent_students && moral_votes[0]    <= max_number_of_excellent_students) ||
             !(strength_votes[0] >= min_number_of_excellent_students && strength_votes[0] <= max_number_of_excellent_students) ||
             !(ability_votes[0]  >= min_number_of_excellent_students && ability_votes[0]  <= max_number_of_excellent_students) ) {
            is_proportion_legal = false;
        }
        if ( !(moral_votes[1]    >= min_number_of_good_students && moral_votes[1]    <= max_number_of_good_students) ||
             !(strength_votes[1] >= min_number_of_good_students && strength_votes[1] <= max_number_of_good_students) ||
             !(ability_votes[1]  >= min_number_of_good_students && ability_votes[1]  <= max_number_of_good_students) ) {
            is_proportion_legal = false;
        }
        if ( !((moral_votes[2]    + moral_votes[3])    >= min_number_of_medium_students && (moral_votes[2]    + moral_votes[3])    <= max_number_of_medium_students) ||
             !((strength_votes[2] + strength_votes[3]) >= min_number_of_medium_students && (strength_votes[2] + strength_votes[3]) <= max_number_of_medium_students) ||
             !((ability_votes[2]  + ability_votes[3])  >= min_number_of_medium_students && (ability_votes[2]  + ability_votes[3])  <= max_number_of_medium_students) ) {
            is_proportion_legal = false;
        }

        return is_proportion_legal;
    }
</script>
<script type="text/javascript">
    function show_current_votes(moral_votes, strength_votes, ability_votes, is_legal) {
        $.globalMessenger().post({
          message: "The number of the currently selected:<br />" + 
                   "[moral] excellent: " + moral_votes[0]      + "People, good: " + moral_votes[1]  + 
                      "People, the: " + moral_votes[2]      + "People poor: " + moral_votes[3] + "people<br />" +
                   "[physical education] excellent: " + strength_votes[0]   + "People, good: " + strength_votes[1]  + 
                      "People, the: " + strength_votes[2]   + "People poor: " + strength_votes[3] + "people<br />" +
                   "[ability] excellent: " + ability_votes[0]    + "People, good: " + ability_votes[1]  + 
                      "People, the: " + ability_votes[2]    + "People poor: " + ability_votes[3] + "people<br />",
          type: ( is_legal ? 'success' : 'error' ),
          showCloseButton: true
        });
    }
</script>
<script type="text/javascript">
    function post_votes_request() {
        var votes    = get_votes_statistics();
        var is_legal = is_all_proportion_legal(votes.moral_votes, votes.strength_votes, votes.ability_votes);
        if ( !is_legal ) {
            post_error_message('Submit data is not legitimate.');
            return;
        }
        $.globalMessenger().post('Being submitted, please wait…');
        set_loading_mode(true);
        var post_data = prepare_votes_data();
        $.ajax({
            type: 'POST',
            async: true,
            url: "<?php echo base_url().'home/post_votes/'; ?>",
            data: post_data,
            dataType: 'JSON',
            success: function(result) {
                if ( result['is_successful'] ) {
                    load('assessment');
                    $.globalMessenger().hideAll();
                    set_loading_mode(false);
                } else {
                    if ( !result['is_peer_assessment_active'] ) {
                        post_error_message('Student peer assessment system is turned off, please contact your system administrator.');
                    } else if ( result['is_participated'] ) {
                        post_error_message('You have participated in student peer assessment, please do not submit duplicate data.');
                    } else if ( !result['is_post_successful'] ) {
                        post_error_message('Failed to submit data, please check the legitimacy of data.');
                    }
                    set_loading_mode(false);
                }
            },
            error: function() {
                post_error_message('An unknown error occurred.');
                set_loading_mode(false);
            }
        });
    }
</script>
<script type="text/javascript">
    function set_loading_mode(is_loading) {
        if ( is_loading ) {
            $('table :input').attr('disabled', true);
            $('button').attr('disabled', true);
        } else {
            $('table :input').removeAttr('disabled');
            $('button').removeAttr('disabled');
        }
    }
</script>
<script type="text/javascript">
    function prepare_votes_data() {
        <?php
            foreach ( $students as $student ) {
                if ( $student['student_id'] == $extra['student_id'] ) {
                    continue;
                }
                $student_id = $student['student_id'];
                echo 'var moral_'.$student_id.'='."$('input[name=\"moral-$student_id\"]:checked').val(),";
                echo 'strength_'.$student_id.'='."$('input[name=\"strength-$student_id\"]:checked').val(),";
                echo 'ability_'.$student_id.'='."$('input[name=\"ability-$student_id\"]:checked').val();\n";
            }
        ?>
        var post_data = <?php
            $is_empty = true;
            foreach ( $students as $student ) {
                $student_id = $student['student_id'];
                if ( $student_id == $extra['student_id'] ) {
                    continue;
                }
                echo ( $is_empty ? "'" : "+'&" );
                echo "moral-$student_id='+".'moral_'.$student_id;
                echo "+'&strength-$student_id='+".'strength_'.$student_id;
                echo "+'&ability-$student_id='+".'ability_'.$student_id;
                $is_empty = false;
            }
        ?>;
        return post_data;
    }
</script>
<script type="text/javascript">
    function post_error_message(error_message) {
        $.globalMessenger().post({
            message: error_message,
            type: 'error',
            actions: {
                retry: {
                    label: 'Retry',
                    action: function() {
                        post_votes_request();
                    }
                },
                cancel: {
                    label: 'cancel',
                    action: function() {
                        $.globalMessenger().hideAll();
                    }
                }
            }
        });
    }
</script>
<script type="text/javascript">
    function reset_options() {
        var result = confirm('Are you sure you want to reset all the options it?This operation can not be restored!');
        if (result == true) {
            $('.good').prop('checked', true);
            $.globalMessenger().hideAll();
            $('#main-container').scrollTop(0);
      }
    }
</script>