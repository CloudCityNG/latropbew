<div id="footer">
	<span id="copyright">
	Copyright&copy; 2016-<?php echo date('Y'); ?> <a href="#" target="_blank">Evangel University MIS/ICT</a>. All rights reserved.
	</span> <!-- /copyright -->
	<span id="help-and-support">
		<ul class="inline">
			<li><a href="#">CloudCity</a></li>
			<li><a href="<?php echo base_url(); ?>support/about">ABOUT</a></li>
		</ul>
	</span> <!-- /help-and-support -->
</div> <!-- /footer -->
<!-- MailerLite Universal --> <script> (function(m,a,i,l,e,r){ m['MailerLiteObject']=e;function f(){ var c={ a:arguments,q:[]};var r=this.push(c);return "number"!=typeof r?r:f.bind(c.q);} f.q=f.q||[];m[e]=m[e]||f.bind(f.q);m[e].q=m[e].q||f.q;r=a.createElement(i); var _=a.getElementsByTagName(i)[0];r.async=1;r.src=l+'?'+(~~(new Date().getTime()/10000000)); _.parentNode.insertBefore(r,_);})(window, document, 'script', 'https://static.mailerlite.com/js/universal.js', 'ml'); var ml_account = ml('accounts', '789496', 'm5b3y0c1s6', 'load'); </script> <!-- End MailerLite Universal -->