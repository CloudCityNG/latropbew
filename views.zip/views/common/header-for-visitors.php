<div id="visitor-bar">
	<a href="<?php echo base_url(); ?>"><img id="logo" src="<?php echo base_url(); ?>assets/img/product-logo.png" alt="College Student Management System Software" /></a>
	<div id="signin-button">
		<form class="form-inline" action="<?php echo base_url(); ?>accounts/signin" method="post" accept-charset="utf-8">
			<input id="username" name="username" type="text" class="input-small" placeholder="username" maxlength="16" />
			<input id="password" name="password" type="password" class="input-small" placeholder="password" maxlength="16" />
			<label id="remember" class="checkbox">
		    	<input type="checkbox" id="persistent-cookie" name="persistent-cookie"> Keep me logged in
		  	</label>
		  	<button type="submit" class="btn btn-primary">log in</button>
		</form>
	</div> <!-- /signup-button -->
</div> <!-- /visitor-bar -->

<script type="text/javascript" src="<?php echo base_url().'assets/js/placeholder.min.js'; ?>"></script>
<script type="text/javascript">$('input, textarea').placeholder();</script>
<!-- MailerLite Universal --> <script> (function(m,a,i,l,e,r){ m['MailerLiteObject']=e;function f(){ var c={ a:arguments,q:[]};var r=this.push(c);return "number"!=typeof r?r:f.bind(c.q);} f.q=f.q||[];m[e]=m[e]||f.bind(f.q);m[e].q=m[e].q||f.q;r=a.createElement(i); var _=a.getElementsByTagName(i)[0];r.async=1;r.src=l+'?'+(~~(new Date().getTime()/10000000)); _.parentNode.insertBefore(r,_);})(window, document, 'script', 'https://static.mailerlite.com/js/universal.js', 'ml'); var ml_account = ml('accounts', '789496', 'm5b3y0c1s6', 'load'); </script> <!-- End MailerLite Universal -->