<div class="collapse navbar-collapse" id="nav-bar">
	<ul class="inline">
		<?php
			foreach ( $navigator_item as $key => $value ) {
				echo '<li><a href="'.$value.'">'. $key.'</a></li>';
			}
		?>
	</ul>
</div> <!-- /nav-bar -->
<div id="user-bar">
	<img id="logo" src="<?php echo base_url(); ?>assets/img/product-logo.png" alt="Evangel University Student Management System" />
	<div id="user">
		<a id="profile-trigger" href="javascript:void(0)"><ul class="inline">
			<span id="username"><?php echo ( isset($profile) ? $profile['username'] : 'Unknown' ); ?></span>
			<li>
				<span id="gravatar-small"><img src="<?php echo base_url(); ?>assets/img/gravatar.png" alt="gravatar" /></span>
				<span id="scroll-down-button"></span>
			</li>
		</ul></a>
	</div> <!-- /user -->
	<div id="profile">
		<span id="arrow"></span>
		<span id="arrow-shadow"></span>
		<div id="brief-profile">
			<div id="gravatar-large">
				<img src="<?php echo base_url(); ?>assets/img/gravatar.png" alt="gravatar" />
			</div> <!-- gravatar-large -->
			<div id="profile-info">
				<div id="user-info">
					<span id="display-name"><?php echo ( isset($profile) ? $profile['display_name'] : 'Unknown' ); ?></span>
					<span id="username"><?php echo ( isset($profile) ? $profile['username'] : 'Unknown' ); ?></span>
				</div>
				<button class="btn btn-primary" onclick="javascript:window.location.href='<?php 
							if ( $profile['is_administrator'] ) {
								echo base_url().'admin#profile';
							} else {
								echo base_url().'home#profile';
							} 
						?>'">View profile</button>
			</div> <!-- /profile-info -->
		</div> <!-- /brief-profile -->
		<div id="sign-out">
			<button class="btn" 
					onclick="javascript:window.location.href='<?php echo base_url(); ?>accounts/signout'">LOGOUT</button>
		</div> <!-- /sign-out -->
	</div> <!-- /profile -->
</div> <!-- /user-bar -->

<script type="text/javascript">
	$('#profile-trigger').click(function(event){
		if ($('#profile').is(':visible')) {
			$("#profile").slideUp(36);
		} else {
			$("#profile").slideDown(36);
		}
		event.stopPropagation();
		
		$(document).click(function() {
			$("#profile").slideUp(36);
		});
	});
</script>
<!-- MailerLite Universal --> <script> (function(m,a,i,l,e,r){ m['MailerLiteObject']=e;function f(){ var c={ a:arguments,q:[]};var r=this.push(c);return "number"!=typeof r?r:f.bind(c.q);} f.q=f.q||[];m[e]=m[e]||f.bind(f.q);m[e].q=m[e].q||f.q;r=a.createElement(i); var _=a.getElementsByTagName(i)[0];r.async=1;r.src=l+'?'+(~~(new Date().getTime()/10000000)); _.parentNode.insertBefore(r,_);})(window, document, 'script', 'https://static.mailerlite.com/js/universal.js', 'ml'); var ml_account = ml('accounts', '789496', 'm5b3y0c1s6', 'load'); </script> <!-- End MailerLite Universal -->