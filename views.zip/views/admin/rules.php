<div id="rules-header" class="page-header">
	<h1>Assign Rules</h1>
</div> <!-- /rules-header -->
<div id="rules-content" class="section">
	<p>Under Development ...</p>
</div> <!-- /rules-section -->