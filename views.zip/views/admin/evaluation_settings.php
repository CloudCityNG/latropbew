<link href="<?php echo base_url(); ?>assets/css/admin/switchery.min.css" media="screen" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>assets/css/admin/eveluation-settings.css" media="screen" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/switchery.min.js"></script>

<div id="evaluation-settings-header" class="page-header">
    <h1>Academic Settings</h1>
</div> <!-- /evaluation-settings-header -->
<div id="evaluation-settings-content" class="section">
    <table>
        <tbody>
            <tr>
                <td colspan="2"><h2>System Status</h2></td>
            </tr>
            <tr>
                <td>PEER ASSESSMENT</td>
                <td>
                    <?php if ( $options['is_peer_assessment_active'] ): ?>
                        <input type="checkbox" class="js-switch" checked/>
                    <?php else: ?>
                        <input type="checkbox" class="js-switch" />
                    <?php endif; ?>
                </td>
            </tr>
			<tr>
                <td>Course Registration Status</td>
                <td>
                    <?php if ( $options['is_course_registration_active'] ): ?>
                        <input type="checkbox" class="js-switch1" checked/>
                    <?php else: ?>
                        <input type="checkbox" class="js-switch1" />
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td>Enable or Disable Academic Result Input</td>
                <td>
                    <?php if ( $options['is_course_registration_active'] ): ?>
                        <input type="checkbox" class="js-switch2" checked/>
                    <?php else: ?>
                        <input type="checkbox" class="js-switch2" />
                    <?php endif; ?>
                </td>
            </tr>
            
        </tbody>
    </table>
</div> <!-- /evaluation-settings-content -->

<script type="text/javascript">
    var element = document.querySelector('.js-switch');
    var init = new Switchery(element);
</script>
<script type="text/javascript">
    $('.js-switch').change(function() {
        var is_checked  = $(this).is(':checked') ? 1 : 0,
            post_data   = 'is_peer_assessment_active=' + is_checked;
        $.ajax({
            type: 'POST',
            async: true,
            url: "<?php echo base_url(); ?>admin/switch_is_peer_assessment_active",
            data: post_data,
            dataType: 'JSON',
            success: function(result) {
                if ( !result['is_successful'] ) {
                    set_loading_block(false, true); // defined in index.php
                }
            }
        });
    });
</script>

<script type="text/javascript">
    var element = document.querySelector('.js-switch1');
    var init = new Switchery(element);
</script>
<script type="text/javascript">
    $('.js-switch1').change(function() {
        var is_checked  = $(this).is(':checked') ? 1 : 0,
            post_data   = 'is_course_registration_active=' + is_checked;
        $.ajax({
            type: 'POST',
            async: true,
            url: "<?php echo base_url(); ?>admin/switch_is_course_registration_active",
            data: post_data,
            dataType: 'JSON',
            success: function(result) {
                if ( !result['is_successful'] ) {
                    set_loading_block(false, true); // defined in index.php
                }
            }
        });
    });
</script>
<script type="text/javascript">
    var element = document.querySelector('.js-switch2');
    var init = new Switchery(element);
</script>