<link href="<?php echo base_url(); ?>assets/css/fineuploader.min.css" media="screen" rel="stylesheet" type="text/css" />

<div id="add-users-header" class="page-header">
    <h1>Add user</h1>
</div> <!-- /add-users-header -->
<div id="add-users-section" class="section">
    <div class="tabbable">
        <ul class="nav nav-tabs">
            <li id="add-a-user-nav" class="active"><a href="javascript:void(0)">Adding a single user</a></li>
            <li id="add-users-nav"><a href="javascript:void(0)">Add multiple users</a></li>
        </ul>
        <div class="tab-content">
            <div id="add-a-user-tab" class="tab-pane active">
                <div id="add-a-user-header" class="page-header">
                    <h2>User Info</h2>
                </div> <!-- /add-a-user-header -->
				<?php if (isset($message)) { ?>
<CENTER><h3 style="color:green;">Data inserted successfully</h3></CENTER><br>
<?php } ?>
                <div id="add-a-user-section" style="overflow: hidden">
                    <div id="add-a-user-message" class="alert hide"></div>
                    <table class="table no-border">
                        <tr class="no-border">
                            <td class="text">student ID</td>
                            <td><input type="text" name="student_id" maxlength="16" /></td>
                            <td class="text">Full name</td>
                            <td><input type="text" name="student_name"　maxlength="24" /></td>
                        </tr>
                        <tr class="no-border">
                            <td class="text">Admission Year</td>
                            <td>
                                <div class="input-append">
                                    <input class="span1" name="grade" type="text" maxlength="4">
                                    <span class="add-on">Year</span>
                                </div>
                            </td>
                            <td class="text">class</td>
                            <td>
                                <div class="input-append">
                                    <input class="span1" name="class" type="text" maxlength="2">
                                    <span class="add-on">class</span>
                                </div>
                            </td>
                        </tr>
                        <tr class="no-border">
                            <td class="text">Room</td>
                            <td><input type="text" name="room" maxlength="8" placeholder="eg. 6#N318" /></td>
                            <!--td class="text">password</td>
                            <td><input type="password" name="password"　maxlength="32" /></td>-->
                        </tr>
                        <tr class="no-border">
                            <td>
                                <input id="upload" type="submit" class="btn btn-primary" value="confirm" onclick="javascript:post_add_user_request()" />
                                <button class="btn" onclick="javascript:reset()">Reset</button>
                            </td>
                        </tr>
                    </table>
                </div> <!-- /add-a-user-section -->
            </div> <!-- /add-a-user-tab -->
            <div id="add-users-tab" class="tab-pane">
                <div id="add-users-header" class="page-header">
                    <h2>Import from Excel file</h2>
                </div> <!-- /add-users-header -->
                <div id="add-users-section" style="overflow: hidden">
                    <form action="<?php echo base_url(); ?>admin/add_users" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                        <table class="table no-border">
                            <tr class="no-border">
                                <td><small><a href="<?php echo base_url().'assets/tpl/template-users.xlsx'; ?>">View document templates</a></small></td>
                            </tr>
                            <tr class="no-border">
                                <td><div id="jquery-wrapped-fine-uploader"></div></td>
                            </tr>
                        </table>
                    </form>
                </div> <!-- /add-users-section -->
            </div> <!-- /add-users-tab -->
        </div> <!-- /tab-content -->
    </div> <!-- /tabbable -->
</div> <!-- /add-users-section -->

<script type="text/javascript">
    $('#add-users-nav').click(function(){
        $('#add-a-user-nav').removeClass('active');
        $('#add-a-user-tab').removeClass('active');
        $('#add-users-nav').addClass('active');
        $('#add-users-tab').addClass('active');
        set_footer_position();
    });
    $('#add-a-user-nav').click(function(){
        $('#add-users-nav').removeClass('active');
        $('#add-users-tab').removeClass('active');
        $('#add-a-user-nav').addClass('active');
        $('#add-a-user-tab').addClass('active');
        set_footer_position();
    });
</script>

<!-- JavaScript for add a user tab -->
<script type="text/javascript" src="<?php echo base_url().'assets/js/placeholder.min.js'; ?>"></script>
<script type="text/javascript">$('input, textarea').placeholder();</script>
<script type="text/javascript">
  $(document).ready( function () {
      $('#table_id').DataTable();
  } );
    var save_method; //for save method string
    var table;


    function add_book()
    {
      save_method = 'add';
      $('#form')[0].reset(); // reset form on modals
      $('#modal_form').modal('show'); // show bootstrap modal
    //$('.modal-title').text('Add Person'); // Set Title to Bootstrap modal title
    }

    function edit_book(id)
    {
      save_method = 'update';
      $('#form')[0].reset(); // reset form on modals

      //Ajax Load data from ajax
      $.ajax({
        url : "<?php echo site_url('admin/ajax_edit/')?>/" + id,
        type: "GET",
        dataType: "JSON",
        success: function(data)
        {

            $('[name="book_id"]').val(data.book_id);
            $('[name="book_isbn"]').val(data.book_isbn);
            $('[name="book_title"]').val(data.book_title);
            $('[name="book_author"]').val(data.book_author);
            $('[name="book_category"]').val(data.book_category);


            $('#modal_form').modal('show'); // show bootstrap modal when complete loaded
            $('.modal-title').text('Edit Book'); // Set title to Bootstrap modal title

        },
        error: function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
    }



    function save()
    {
      var url;
      if(save_method == 'add')
      {
          url = "<?php echo site_url('admin/book_add')?>";
      }
      else
      {
        url = "<?php echo site_url('admin/book_update')?>";
      }

       // ajax adding data to database
          $.ajax({
            url : url,
            type: "POST",
            data: $('#form').serialize(),
            dataType: "JSON",
            success: function(data)
            {
               //if success close modal and reload ajax table
               $('#modal_form').modal('hide');
              location.reload();// for reload a page
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Added / Updated Data Successfully');
            }
        });
    }

    function delete_book(id)
    {
      if(confirm('Are you sure delete this data?'))
      {
        // ajax delete data from database
          $.ajax({
            url : "<?php echo site_url('admin/book_delete')?>/"+id,
            type: "POST",
            dataType: "JSON",
            success: function(data)
            {
               
               location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                alert('Error deleting data');
            }
        });

      }
    }

  </script>
<script type="text/javascript">
    function reset() {
        var result = confirm('Are you sure you want to reset it?\nThis operation can not be restored!');
        if (result == true) {
            $('input[type="text"]').val('');
            $('input[type="password"]').val('');
        }
    }
</script>

<!-- JavaScript for add users tab -->
<script type="text/javascript" src="<?php echo base_url().'assets/js/fineuploader.min.js'; ?>"></script>
<script>
    $(document).ready(function () {
        $('#jquery-wrapped-fine-uploader').fineUploader({
            request: {
                endpoint: "<?php echo base_url(); ?>" + 'admin/add_users/'
            },
            text: {
                uploadButton: 'upload files'
            }
        }).on('complete', function(event, id, file_name, result) {
            if ( result['is_successful'] ) {
                $('.fileUploader-upload-fail').last().addClass('fileUploader-upload-success');
                $('.fileUploader-upload-fail').last().removeClass('fileUploader-upload-fail');
                $('.fileUploader-upload-status-text').last().html('All student information has been successfully imported. <a href="#logs"><small>see details</small></a>');
            } else {
                if ( !result['is_upload_successful'] ) {
                    $('.fileUploader-upload-status-text').last().html(result['error_message']);
                } else {
                    $('.fileUploader-upload-status-text').last().html('Some students of the information was not imported successfully. <a href="#logs"><small>see details</small></a>');
                }
            }
        });
    });
</script>
