<link href="<?php echo base_url(); ?>assets/css/fineuploader.min.css" media="screen" rel="stylesheet" type="text/css" />

<div id="add-users-header" class="page-header">
    <h1>Add Staff</h1>
	</div>
</div> <!-- /add-users-header -->
<div id="add-users-section" class="section">
    <div class="tabbable">
        <ul class="nav nav-tabs">
            <li id="add-a-user-nav" class="active"><a href="javascript:void(0)">Adding a Single Staff</a></li>
            <li id="add-users-nav"><a href="javascript:void(0)">Add Multiple Staff</a></li>
        </ul>
        <div class="tab-content">
            <div id="add-a-user-tab" class="tab-pane active">
                <div id="add-a-user-header" class="page-header">
                
                    <h2>Staff Information</h2>
                </div> <!-- /add-a-user-header -->
                <?php $msg = $this->session->flashdata('msg'); if((isset($msg)) && (!empty($msg))) { ?>
                <div class="alert alert-success" >

                  <a href="#" class="close" data-dismiss="alert">&times;</a>
                <?php print_r($msg); ?>
                </div>
                <?php } ?>
                <?php $msg = $this->session->flashdata('msg1'); if((isset($msg)) && (!empty($msg))) { ?>
                <div class="alert alert-error" >

                  <a href="#" class="close" data-dismiss="alert">&times;</a>
                <?php print_r($msg); ?>
                </div>
                <?php } ?>
				<form name="myform" class="form-horizontal" action="<?php echo base_url();?>admin/add_staff"  method="post">
				
                <div id="add-a-user-section" style="overflow: hidden">
                    <div id="add-a-user-message" class="alert hide"></div>
                    <table class="table no-border">
                        <tr class="no-border">
                            <td class="text">Staff Employment ID</td>
                            <td><input type="text" class="form-control" required name="student_id" maxlength="16" placeholder="E.g: EU/SC/MTH/13/007" /></td>
                            <td class="text c1ontrol-label">Full name</td>
                            <td><input type="text" class="form-control" required name="student_name"　maxlength="29" /></td>
                        </tr>
                        <tr class="no-border">
                            <td class="text">Employment Year</td>
                            <td>
                                <div class="input-append" required>
                                    <input class="span1 form-control" name="grade" type="text" maxlength="4" required>
                                    <span class="add-on">Year</span>
                                </div>
                            </td>
                            <td class="text">Gender</td>
                            <td>
                                <div class="input-append" required>
                                    <input class="span1 form-control" name="class" type="text" maxlength="1" placeholder="M for Male & F for Female">
                                    <span class="add-on">M or F</span>
                                </div>
                            </td>
                        </tr>
                        <tr class="no-border">
                            <td class="text">Hostel</td>
                            <td><input type="text" class="form-control" required name="room" maxlength="11" placeholder="eg. Hostel E-2" /></td>
                            <td class="text">password</td>
                            <td><input type="password" class="form-control" required  name="password"　maxlength="32" disabled placeholder="99193636" /></td>
                        </tr>
                        <tr class="no-border">
                            <td>
                                <input id="upload" type="submit" class="btn btn-primary" value="Submit"/>
                                <button class="btn" type="reset">Reset</button>
                            </td>
                        </tr>
                    </table>
                </div> <!-- /add-a-user-section -->
            </div>
			<!-- /add-a-user-tab -->
			</form>
            <div id="add-users-tab" class="tab-pane">
			
                <div id="add-users-header" class="page-header">
                    <h2>Import from Excel file</h2>
                </div> <!-- /add-users-header -->
                <div id="add-users-section" style="overflow: hidden">
                    <form action="<?php echo base_url(); ?>admin/add_users" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                        <table class="table no-border">
                            <tr class="no-border">
                                <td><small><a href="<?php echo base_url().'assets/tpl/template-users.xlsx'; ?>">View document templates</a></small></td>
                            </tr>
                            <tr class="no-border">
                                <td><div id="jquery-wrapped-fine-uploader"></div></td>
                            </tr>
                        </table>
                    </form>
                </div> <!-- /add-users-section -->
            </div> <!-- /add-users-tab -->
        </div> <!-- /tab-content -->
    </div> <!-- /tabbable -->
</div> <!-- /add-users-section -->

<script>
    $(document).ready(function () {
        $('#jquery-wrapped-fine-uploader').fineUploader({
            request: {
                endpoint: "<?php echo base_url(); ?>" + 'admin/add_users/'
            },
            text: {
                uploadButton: 'upload files'
            }
        }).on('complete', function(event, id, file_name, result) {
            if ( result['is_successful'] ) {
                $('.fileUploader-upload-fail').last().addClass('fileUploader-upload-success');
                $('.fileUploader-upload-fail').last().removeClass('fileUploader-upload-fail');
                $('.fileUploader-upload-status-text').last().html('All student information has been successfully imported. <a href="#logs"><small>see details</small></a>');
            } else {
                if ( !result['is_upload_successful'] ) {
                    $('.fileUploader-upload-status-text').last().html(result['error_message']);
                } else {
                    $('.fileUploader-upload-status-text').last().html('Some students of the information was not imported successfully. <a href="#logs"><small>see details</small></a>');
                }
            }
        });
    });
</script>
<script type="text/javascript">
    $('#add-users-nav').click(function(){
        $('#add-a-user-nav').removeClass('active');
        $('#add-a-user-tab').removeClass('active');
        $('#add-users-nav').addClass('active');
        $('#add-users-tab').addClass('active');
        set_footer_position();
    });
    $('#add-a-user-nav').click(function(){
        $('#add-users-nav').removeClass('active');
        $('#add-users-tab').removeClass('active');
        $('#add-a-user-nav').addClass('active');
        $('#add-a-user-tab').addClass('active');
        set_footer_position();
    });
</script>

<!-- JavaScript for add a user tab -->
<script type="text/javascript" src="<?php echo base_url().'assets/js/placeholder.min.js'; ?>"></script>
<script type="text/javascript">$('input, textarea').placeholder();</script>

<script type="text/javascript">
    function reset() {
        var result = confirm('Are you sure you want to reset it?\nThis operation can not be restored!');
        if (result == true) {
            $('input[type="text"]').val('');
            $('input[type="password"]').val('');
        }
    }
	function validateForm() {
    var x = document.forms["myform"]["student_id"].value;
    if (x == "") {
        alert("Name must be filled out");
        return false;
    }
}
</script>

<!-- JavaScript for add users tab -->

<script type="text/javascript">
    $(document).ready(function() {

        $("input[id^='upload_file']").each(function() {

            var id = parseInt(this.id.replace("upload_file", ""));
            
            $("#upload_file" + id).change(function() {
                if ($("#upload_file" + id).val() !== "") {
                    $("#moreImageUploadLink").show();
                }
            });
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        var upload_number = 2;
        $('#attachMore').click(function() {
            //add more file
            var moreUploadTag = '';
            moreUploadTag += '<div class="element"><label for="upload_file"' + upload_number + '>Upload File ' + upload_number + '</label>';
            moreUploadTag += '<input type="file" id="upload_file' + upload_number + '" name="upload_file' + upload_number + '"/>';
            moreUploadTag += '&nbsp;<a href="javascript:del_file(' + upload_number + ')" style="cursor:pointer;" onclick="return confirm(\"Are you really want to delete ?\")">Delete ' + upload_number + '</a></div>';
            $('<dl id="delete_file' + upload_number + '">' + moreUploadTag + '</dl>').fadeIn('slow').appendTo('#moreImageUpload');
            upload_number++;
        });
    });
</script>
<script type="text/javascript">
    function del_file(eleId) {
        var ele = document.getElementById("delete_file" + eleId);
        ele.parentNode.removeChild(ele);
    }
</script>