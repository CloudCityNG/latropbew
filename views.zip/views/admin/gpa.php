<div id="printArea">
<div id="gpa-header" class="page-header">
    <h1>Senate Report Academic Evaluation</h1>
</div> <!-- /gpa-header -->
<div id="gpa-content" class="section">
	<div id="selector">
		<select id="available-grades" class="span2">
			<?php
				foreach ( $available_grades as $available_grade ) {
					$grade = $available_grade['grade'];
					echo '<option value="'.$grade.'">'.$grade.' Set</option>';
				}
			?>
		</select>
	</div> <!-- /selector -->
	<p>
	<a href="#payment" class="btn btn-warning" role="button">WORD</a>  
	<a href="#payment" class="btn btn-default" role="button">PDF</a>  
	<a href="#payment" class="btn btn-success" role="button">EXCEL</a> 
	<a href="#payment" onclick="javascript:printDiv('printArea')" id="btnPrint" class="btn btn-success" role="button">PRINT</a> 
    </p>
	<div id="list">
        <table id="gpa-records" class="table table-striped">
            <thead>
                <tr>
                    <td>Grade</td>
                    <td>Student ID</td>
                    <td>Student Name</td>
                    <td>Total Grade Point</td>
                    <td>Total Credit(s)</td>
                    <td>GPA</td>
                    <td>Ranking</td>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
    </div> <!-- /list -->
    <div id="page-error" class="alert alert-error hide"><strong>Alert: </strong>An error occured.</div>
</div> <!-- /gpa-content -->
</div><!-- dvContainer-->

<!-- Print Area for div  -->
<script language="javascript" type="text/javascript">
        function printDiv(divID) {
            //Get the HTML of div
            var divElements = document.getElementById(divID).innerHTML;
            //Get the HTML of whole page
            var oldPage = document.body.innerHTML;

            //Reset the page's HTML with div's HTML only
            document.body.innerHTML = 
              "<html><head><title></title></head><body>" + 
              divElements + "</body>";

            //Print Page
            window.print();

            //Restore orignal HTML
            document.body.innerHTML = oldPage;

          
        }
    </script>



<!-- JavaScript for gpa -->
<script type="text/javascript">
    function get_gpa_records(grade) {
        $.ajax({
            type: 'GET',
            async: true,
            url: "<?php echo base_url().'admin/get_gpa_records/'; ?>" + grade,
            dataType: 'JSON',
            success: function(result) {
                console.log(result);
                $('#gpa-records tbody').empty();
                if ( result['is_successful'] ) {
                    var total_records = result['records'].length;
                    for ( var i = 0; i < total_records; ++ i ) {
                        $('#gpa-records').append(
                            '<tr>' + 
                                '<td>' + result['records'][i]['grade'] + 'Grade' + result['records'][i]['class'] + ' 班</td>' +
                                '<td>' + result['records'][i]['student_id'] + '</td>' + 
                                '<td>' + result['records'][i]['student_name'] + '</td>' +
                                '<td>' + result['records'][i]['total_grade_points'] + '</td>' +
                                '<td>' + result['records'][i]['total_credits'] + '</td>' +
                                '<td>' + result['records'][i]['gpa'] + '</td>' +
                                '<td>' + result['records'][i]['ranking'] + '</td>' +
                            '</tr>'
                        );
                    }
                    set_visible('#page-error', false);
                    set_visible('#list', true);
                } else {
                    set_visible('#page-error', true);
                    set_visible('#list', false);
                }
            }
        });
    }
</script>
<script type="text/javascript">
    function set_visible(element, is_visible) {
        if ( is_visible ) {
            $(element).css('display', 'block');
        } else {
            $(element).css('display', 'none');
        }
        set_footer_position();  // which is defined in index.php
    }
</script>
<script type="text/javascript">
    function prepare_get_gpa_records() {
        var grade       = $('#available-grades').val();
        return get_gpa_records(grade);
    }
</script>
<script type="text/javascript">
    $('select#available-grades').change(function() {
        return prepare_get_gpa_records();
    });
</script>
<script type="text/javascript">
    $(document).ready(function(){
        prepare_get_gpa_records();
    });
</script>