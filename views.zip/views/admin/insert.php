<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "root", "c115rjxy2");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$student_id = mysqli_real_escape_string($link, $_REQUEST['student_id']);
$student_name = mysqli_real_escape_string($link, $_REQUEST['student_name']);
$grade = mysqli_real_escape_string($link, $_REQUEST['grade']);
$classx = mysqli_real_escape_string($link, $_REQUEST['classx']);
$room = mysqli_real_escape_string($link, $_REQUEST['room']);
$p = mysqli_real_escape_string($link, $_REQUEST['password']);
 
// attempt insert query execution
$sql = "INSERT INTO stumgr_students (student_id, student_name, grade, classx, room, password) VALUES ('$student_id', '$student_name', '$grade', '$classx', '$room', '$password')";
if(mysqli_query($link, $sql)){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// close connection
mysqli_close($link);
?>