<div id="page-error" class="alert alert-error hide"><strong>Alert: </strong>An error occured.</div>
<div id="selector">
    <span>
        <select id="available-grades" class="span3">
            <?php
                foreach ( $available_grades as $available_grade ) {
                    $grade = $available_grade['course_id'];
                    echo '<option value="'.$grade.'">Course Code : '.$grade.' </option>';
                }
            ?>
        </select>
    </span>
    
    <!--span>
        <a href="#"><button id="delete-accounts" class="btn btn-danger float-right" style="margin-bottom: 12px;">Delete All Records</button></a>
    </span>-->
</div> <!-- /selector -->
<p>
	<a href="#payment" class="btn btn-warning" role="button">WORD</a>  
	<a href="#payment" class="btn btn-default" role="button">PDF</a>  
	<a href="#payment" class="btn btn-success" role="button">EXCEL</a> 
	<a href="#edit_users" onclick="javascript:printDiv('printArea')" id="btnPrint" class="btn btn-success" role="button">PRINT</a> 
</p>
<div id="list">
    <table id="students-list" class="table table-striped">
        <thead>
            <tr>
                <td>Matric. No</td>
                <td>Course Code</td>
                <td>Semester</td>
                <td>C/A</td>
                <td>Exam</td>
            </tr>
        </thead>
        <tbody></tbody>
    </table>
</div> <!-- /list -->
</div><!-- dvContainer-->

<!-- Print Area for div  -->
<script language="javascript" type="text/javascript">
        function printDiv(divID) {
            //Get the HTML of div
            var divElements = document.getElementById(divID).innerHTML;
            //Get the HTML of whole page
            var oldPage = document.body.innerHTML;

            //Reset the page's HTML with div's HTML only
            document.body.innerHTML = 
              "<html><head><title></title></head><body>" + 
              divElements + "</body>";

            //Print Page
            window.print();

            //Restore orignal HTML
            document.body.innerHTML = oldPage;

          
        }
    </script>
<!-- Common -->
<script type="text/javascript">
    function set_error_message(element, is_visible) {
        if ( is_visible ) {
            $(element).css('display', 'block');
        } else {
            $(element).css('display', 'none');
        }
        set_footer_position();  // which is defined in index.php
    }
</script>

<!-- Load Students List -->
<script type="text/javascript">
    function get_students_profile_list(grade) {
        $.ajax({
            type: 'GET',
            async: true,
            url: "<?php echo base_url().'admin/get_students_profile_list1/'; ?>" + grade,
            dataType: 'JSON',
            success: function(result) {
                $('#students-list tbody').empty();
                if ( result['is_successful'] ) {
                    var total_students = result['students'].length;
                    for ( var i = 0; i < total_students; ++ i ) {
                        $('#students-list').append(
                            '<tr class="table-datum">' + 
                            '<td>' + result['students'][i]['student_id'] + '</td>' +
                            '<td>' + result['students'][i]['course_id'] + '</td>' +
                            '<td>' + result['students'][i]['semester'] + '</td>' +
                            '<td>' + result['students'][i]['paper_score'] + '</td>' + 
                            '<td>' + result['students'][i]['final_score'] + '</td>' +
                            '</tr>'
                        );
                    }
                    set_error_message('#page-error', false);
                } else {
                    set_error_message('#page-error', true);
                }
            }
        });
    }
</script>
<script type="text/javascript">
    $(document).ready(function(){
        var grade = $("#available-grades").val();
        get_students_profile_list(grade);
        set_footer_position();
    });
    $("#available-grades").change(function() {
        var grade = $("#available-grades").val();
        return get_students_profile_list(grade);
    });
</script>

<!-- Edit Profile -->
<!-- Profile Modal -->
<div id="profile-dialog" class="modal dialog hide">
    <div class="modal-header">
        <button type="button" class="close">×</button>
        <h3 id="profile-dialog-title">Add Result Grade </h3>
    </div>
    <div class="modal-body">
        <div id="dialog-error" class="alert alert-error hide"></div>
        <table class="table no-border">
            <tr class="no-border">
                <td class="text-bold">Matric Number</td>
                <td class="text-normal"><label name="student_id"></label></td>
                <td class="text-bold">Course Code</td>
                <td class="text-normal"><label name="course_id"></label></td>
            </tr>
            <tr class="no-border">
                <td class="text-bold">Semester</td>
                <td>
                    <div class="input-append">
                        <input class="span1" disabled="" name="semester" type="text" maxlength="1">
                        <span class="add-on">Year</span>
                    </div>
                </td>
                <td class="text-bold">Grade</td>
                <td>
                    <div class="input-append">
                        <input class="span1" name="paper_score" type="text" maxlength="2">
                        <span class="add-on">C/A</span>
                    </div>
                    <div class="input-append">
                        <input class="span1" name="final_score" type="text" maxlength="2">
                        <span class="add-on">Exam</span>
                    </div>
                </td>
            </tr>
            <!--<tr class="no-border">
                <td class="text-bold">Programme</td>
                <td>
                    <select name="user-group" class="span2">
                        <?php
                            foreach ( $user_groups as $group ) {
                                echo '<option value="'.$group['group_name'].'">'.$group['display_name'].'</option>';
                            }
                        ?>
                    </select>
                </td>
                <td class="text-bold">Hostel</td>
                <td><input type="text" class="span2" name="room" maxlength="16"></td>
            </tr>
            <tr class="no-border">
                <td class="text-bold">Mobile Number</td>
                <td><input type="text" class="span2" name="mobile" maxlength="11"></td>
                <td class="text-bold">Email</td>
                <td><input type="text" class="span2" name="email" maxlength="36"></td>
            </tr>
            <tr class="no-border">
                <td class="text-bold">Password</td>
                <td><input type="password" class="span2" name="password"　maxlength="16" /></td>
            </tr>-->

        </table>
    </div>
    <div class="modal-footer">
        <button id="delete-account" class="btn btn-danger float-left">Delete</button>
        <button id="edit-profile" class="btn btn-primary">Submit</button>
        <button class="btn btn-cancel">Cancel</button>
    </div>
</div> <!-- /Profile Modal -->

<script type="text/javascript">
    $(document).ready(function(){
        $('#students-list').delegate('tr.table-datum', 'click', function(){
            open_profile_dialog($(this).find('td').first().html());
        });
        $('.close').click(function(){
            close_profile_dialog();
        });
        $('.btn-cancel').click(function(){
            close_profile_dialog();
        });
        $('#edit-profile').click(function(){
            var student_id = $('label[name="student_id"]').text();
            set_loading_mode(true);
            edit_user_profile1(student_id);
        });
    });
</script>
<script type="text/javascript">
    function open_profile_dialog(student_id) {
        get_user_profile1(student_id);
        $('#profile-dialog').fadeIn();
    }
    function close_profile_dialog() {
        $('#profile-dialog').fadeOut();
    }
</script>
<script type="text/javascript">
    function set_loading_mode(is_loading) {
        if ( is_loading ) {
            $('#profile-dialog :input').attr('disabled', true);
        } else {
            $('#profile-dialog :input').removeAttr('disabled');
        }
    }
</script>
<script type="text/javascript">
    function get_user_profile1(student_id) {
        $.ajax({
            type: 'GET',
            async: true,
            url: "<?php echo base_url().'admin/get_user_profile1/'; ?>" + student_id,
            dataType: 'JSON',
            success: function(data) {
                $('label[name="student_id"]').text(data['student_id']);
                $('input[name="course_id"]').val(data['course_id']);
                $('input[name="semester"]').val(data['semester']);
                $('input[name="paper_score"]').val(data['paper_score']);
                $('input[name="final_score"]').val(data['final_score']);
            },
            error: function() {
                $('#dialog-error').html('An unknown error occurred.');
                set_error_message('#dialog-error', false);
            }
        });
    }
</script>
<script type="text/javascript">
    function edit_user_profile1(student_id) {
        var course_id               = $('input[name="course_id"]').val(),
            semester             = $('input[name="semester"]').val(),
            paper_score             = $('input[name="paper_score"]').val(),
            final_score             = $('input[name="final_score"]').val();
            var post_data = 'course_id=' + course_id + '&semester=' + semester + '&paper_score=' + paper_score +
                        '&final_score=' + final_score;
        $.ajax({
            type: 'POST',
            async: true,
            url: "<?php echo base_url().'admin/edit_user_profile1/'; ?>" + student_id,
            data: post_data,
            dataType: 'JSON',
            success: function(result) {
                if ( result['is_successful'] ) {
                    close_profile_dialog();
                    refresh_datum_item(student_id, course_id, semester, paper_score, final_score);
                } else {
                    var error_message = '';
                    if ( result['is_student_name_empty'] ) {
                        error_message += 'Student Name is empty.<br />';
                    } else if ( !result['is_student_name_legal'] ) {
                        error_message += 'Student name entered is not valid .<br />';
                    }
                    if ( result['is_grade_empty'] ) {
                        error_message += 'Admission Year Column is empty.<br />';
                    } else if ( !result['is_grade_legal'] ) {
                        error_message += 'Admission Year entered is not valid.<br />';
                    }
                    if ( result['is_class_empty'] ) {
                        error_message += 'Student Gender is empty.<br />';
                    } else if ( !result['is_class_legal'] ) {
                        error_message += 'Gender entered is not allowed!<br />';
                    }
                    if ( result['is_room_empty'] ) {
                        error_message += 'Hostel is empty.<br />';
                    } else if ( !result['is_room_legal'] ) {
                        error_message += 'Hostel entry is not allowed.<br />';
                    }
                    if ( !result['is_mobile_legal'] ) {
                        error_message += 'Mobile is not valid.<br />';
                    }
                    if ( !result['is_email_legal'] ) {
                        error_message += 'E-mail is not valid.<br />';
                    }
                    if ( !result['is_password_legal'] ) {
                        error_message += 'Password length is from 6-16 characters.<br />';
                    }
                    if ( error_message == '' ) {
                        error_message += 'Alert:.<br />'
                    }
                    $('#dialog-error').html(error_message);
                    set_error_message('#dialog-error', true);
                }
            }
        });
        set_loading_mode(false);
    }
</script>
<script type="text/javascript">
    function refresh_datum_item(student_id, course_id, semester, paper_score, final_score) {
        $('.table-datum').each(function(index) {
            if ( $(this).find('td').first().html() == student_id ) {
                var datum_items = $(this).find('td');
                datum_items.eq(1).html(course_id);
                datum_items.eq(2).html(semester);
                datum_items.eq(3).html(paper_score);
                datum_items.eq(4).html(final_score);
                
            }
        });
    }
</script>
<!-- Delete Accounts -->
<script type="text/javascript">
    $('#delete-account').click(function(){
        var student_id = $('label[name="student_id"]').text();
        set_loading_mode(true);
        delete_account(student_id);
    });
    $('#delete-accounts').click(function(){
        var result = confirm('Are you sure you want to do this?\nThis Action Cannot be Revoked!');
        if (result == true) {
            var grade = $('#available-grades').val();
            $(this).text('请稍候...');
            $(this).prop('disabled', true);
            $('select').prop('disabled', true);
            delete_accounts(grade);
        }
    });
</script>
<script type="text/javascript">
    function delete_account(student_id) {
        $.ajax({
            type: 'GET',
            async: true,
            url: "<?php echo base_url().'admin/delete_account/'; ?>" + student_id,
            dataType: 'JSON',
            success: function(result) {
                if ( result['is_successful'] ) {
                    close_profile_dialog();
                    remove_datum_item(student_id);
                } else {
                    set_error_message('#page-error', false);
                }
            },
            error: function() {
                set_error_message('#page-error', false);
            }
        });
        set_loading_mode(false);
    }
</script>
<script type="text/javascript">
    function remove_datum_item(student_id) {
        $('.table-datum').each(function(index) {
            if ( $(this).find('td').first().html() == student_id ) {
                $(this).remove();
            }
        });
    }
</script>
<script type="text/javascript">
    function delete_accounts(grade) {
        $.ajax({
            type: 'GET',
            async: true,
            url: "<?php echo base_url().'admin/delete_accounts/'; ?>" + grade,
            dataType: 'JSON',
            success: function(result) {
                if ( result['is_successful'] ) {
                    location.reload();
                } else {
                    set_error_message('#page-error', false);
                }
            },
            error: function() {
                set_error_message('#page-error', false);
            }
        });
        set_loading_mode(false);
    }
</script>