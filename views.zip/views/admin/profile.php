<h1 class="redtext">Account Management</h1>
<div id="password-information">
	<div id="password-information-header" class="page-header">
		<span class="title">password</span><span><a id="open-change-password-dialog" href="javascript:void(0)">change the password</a></span>
	</div> <!-- /password-information-header -->
	<div id="password-information-content" class="section">
		<table class="table no-border" style="width: 84%;">
			<tr class="no-border"><td>
				<?php
					if ( $account['last_time_change_password'] == '0000-00-00 00:00:00' ) {
						echo 'You do not have to modify your password, we strongly recommend that you change your password.';	
					} else {
						$time = strtotime($account['last_time_change_password']);
						echo 'Last time you changed your Password: <strong>'.date('Y|m|d H:i',$time).'</strong>';
					}
				?>
			</td></tr>
            
		</table>
	</div> <!-- /password-information-content -->
</div> <!-- /password-information -->

<!-- Password Modal -->
<div id="password-dialog" class="modal hide dialog">
 	<div class="modal-header">
    	<button type="button" class="close">×</button>
    	<h3 id="password-dialog-title">change the password</h3>
  	</div>
  	<div class="modal-body">
  		<div id="password-error-message" class="alert alert-error hide"></div>
    	<table class="table no-border">
    		<tr class="no-border">
    			<td class="text-bold">old password</td>
    			<td><input type="password" name="old-password" maxlength="16" /></td>
    		</tr>
    		<tr class="no-border">
    			<td class="text-bold">new password</td>
    			<td><input type="password" name="new-password" maxlength="16" /></td>
    		</tr>
    		<tr class="no-border">
    			<td class="text-bold">Confirm the new password</td>
    			<td><input type="password" name="password-again" maxlength="16" /></td>
    		</tr>
    	</table>
  	</div>
  	<div class="modal-footer">
 	   <button id="change-password" class="btn btn-primary">confirm</button>
 	   <button class="btn btn-cancel">cancel</button>
 	</div>
</div> <!-- /Password Modal -->

<script type="text/javascript">
	$(document).ready(function() {
		$('#open-change-password-dialog').click(function(){
			$('#password-error-message').css('display', 'none');
            $('#password-dialog').fadeIn();
		});
		$('.close').click(function(){
			$('#password-dialog').fadeOut();
		});
		$('.btn-cancel').click(function(){
			$('#password-dialog').fadeOut();
		});
		$('#change-password').click(function(){
			var old_password = $('input[name="old-password"]').val(),
			    new_password = $('input[name="new-password"]').val(),
			    password_again = $('input[name="password-again"]').val();
            set_loading_mode(true);
			return post_change_password_request(old_password, new_password, password_again);
		});
	});
</script>
<script type="text/javascript">
    function set_loading_mode(is_loading) {
        if ( is_loading ) {
            $('#password-dialog :input').attr('disabled', true);
        } else {
            $('#password-dialog :input').removeAttr('disabled');
        }
    }
</script>
<script type="text/javascript">
	function post_change_password_request(old_password, new_password, password_again) {
        var post_data = 'old_password=' + old_password + '&new_password=' + new_password + 
        				'&password_again=' + password_again;
        $.ajax({
            type: 'POST',
            async: true,
            url: "<?php echo base_url(); ?>" + 'admin/change_password/',
            data: post_data,
            dataType: 'JSON',
            success: function(result) {
            	if ( !result['is_successful'] ) {
            		var error_message = '';
            		if ( result['is_old_password_empty'] ) {
            			error_message += 'Please fill in the old password.<br />';
            		}
            		if ( result['is_new_password_empty'] ) {
            			error_message += 'Please fill in the new password.<br />';
            		} else if ( !result['is_new_password_length_legal'] ) {
            			error_message += 'The new password must be 6-16 characters.<br />';
            		}
            		if ( result['is_password_again_empty'] ) {
            			error_message += 'Please confirm your new password.<br />';
            		} else if ( !result['is_password_again_matched'] ) {
            			error_message += 'Enter the new password twice inconsistent.<br />';
            		}
                    if ( error_message == '' ) {
                        if ( !result['is_old_password_correct'] ) {
                            error_message = 'Old password is incorrect.<br />';
                        }
                    }
            		$('#password-error-message').html(error_message);
            		$('#password-error-message').fadeIn();
            	} else {
            		load('profile');  // Reload the div content
            	}
            },
            error: function() {
                $('#password-error-message').html('An unknown error occurred');
                $('#password-error-message').fadeIn();
            }
        });
        set_loading_mode(false);
    }
</script>