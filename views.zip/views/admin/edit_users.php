<div id="printArea">

<div id="edit-users-header" class="page-header">
    <h1>Users Management Panel Students' Affairs Division</h1>
</div> <!-- /edit-users-header -->
<div id="edit-users-section" class="section">
    <?php if ( isset($available_grades) && $available_grades ): ?>
    	<?php require_once(APPPATH.'views/admin/editusers_content.php'); ?>
    <?php else: ?>
        <div class="alert alert-error"><strong>Tips: </strong>No data available.</div>
    <?php endif; ?>
</div> <!-- /edit-users-header -->