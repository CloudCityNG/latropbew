<!DOCTYPE html>
<html>
<head>
	<title>Admininistrator Area- Evangel University Management System</title>
	<meta charset='utf-8' />
	<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<!-- Page Icon -->
	<link rel="shortcut icon" href="<?php echo base_url(); ?>assets/img/logo.png" />
	<!-- CSS -->
	<!--link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/bootstrap/css/bootstrap.min.css">-->
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/yep-style.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap-responsive.min.css">
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/admin/style.css">
	<!-- Java Script -->
	<script src="<?php echo base_url(); ?>assets/js/jquery-1.11.0.min.js"></script>
</head>

<body>
	<div id="container">
		<div id="header">
			<?php
				require_once APPPATH.'views/common/header-for-users.php';
			?>
		</div> <!-- /header -->
		<div id="content">
			<div id="sidebar">
				<div id="sidebar-nav-frame-welcome" class="sidebar-nav">
					<a href="#welcome"><div id="sidebar-nav-welcome" class="sidebar-primary-nav">Welcome</div></a>
				</div>
				<div id="sidebar-nav-frame-users" class="sidebar-nav">
					<a href="javascript:void(0)"><div id="sidebar-nav-users" class="sidebar-primary-nav">Users Mgt</div></a>
					<a href="#add_users"><div id="sidebar-nav-add_users" class="sidebar-secondary-nav">Add User/ Student</div></a>
					<a href="#add_staff"><div id="sidebar-nav-add_users" class="sidebar-secondary-nav">Add Staff</div></a>
					<a href="#edit_users"><div id="sidebar-nav-edit_users" class="sidebar-secondary-nav">User Management</div></a>
				</div>
				<!--div id="sidebar-nav-frame-routine" class="sidebar-nav">
					<a href="javascript:void(0)"><div id="sidebar-nav-routine" class="sidebar-primary-nav">Routine</div></a>
					<a href="#rules"><div id="sidebar-nav-rules" class="sidebar-secondary-nav">Rules</div></a>
					<a href="#attendance"><div id="sidebar-nav-attendance" class="sidebar-secondary-nav">Attendance</div></a>
					<a href="#hygiene"><div id="sidebar-nav-hygiene" class="sidebar-secondary-nav">Hygiene</div></a>
				</div>-->
				<div id="sidebar-nav-frame-scores" class="sidebar-nav">
					<a href="javascript:void(0)"><div id="sidebar-nav-scores" class="sidebar-primary-nav">Bursary</div></a>
					<a href="#payment"><div id="sidebar-nav-payment" class="sidebar-secondary-nav">Add School Fees Payment Record</div></a>
				</div>
				<div id="sidebar-nav-frame-scores" class="sidebar-nav">
					<a href="javascript:void(0)"><div id="sidebar-nav-scores" class="sidebar-primary-nav">Academics</div></a>
					<!--a href="#input_results"><div id="sidebar-nav-input_results" class="sidebar-secondary-nav">Input Results</div></a>-->
					<a href="#score_settings"><div id="sidebar-nav-score_settings" class="sidebar-secondary-nav">Import Result/ Courses Overview</div></a>
					<a href="#resinput"><div id="sidebar-nav-resinput" class="sidebar-secondary-nav">Result Input</div></a>
					<!--a href="#add_courses"><div id="sidebar-nav-add_courses" class="sidebar-secondary-nav">Add Courses</div></a>
					<a href="#transcripts"><div id="sidebar-nav-transcripts" class="sidebar-secondary-nav">Result Analysis</div></a>-->
					<a href="#approveReg"><div id="sidebar-nav-reg-approve" class="sidebar-secondary-nav">Approve Registration</div></a>
					<!--a href="#gpa"><div id="sidebar-nav-gpa" class="sidebar-secondary-nav">Senate Report Evaluation</div></a>
					<a href="#report"><div id="sidebar-nav-gpa2" class="sidebar-secondary-nav">Report Evaluation</div></a>-->
					<a href="#reseval"><div id="sidebar-nav-reseval" class="sidebar-secondary-nav">Senate Report Result Evaluation</div></a>
					
				</div>
				<div id="sidebar-nav-frame-evaluation" class="sidebar-nav">
					<a href="javascript:void(0)"><div id="sidebar-nav-evaluation" class="sidebar-primary-nav">Options</div></a>
					<a href="#evaluation_settings"><div id="sidebar-nav-evaluation_settings" class="sidebar-secondary-nav">Academic Settings</div></a>
					<a href="#rules"><div id="sidebar-nav-rules" class="sidebar-secondary-nav">Priviledges</div></a>
					<!--a href="#assessment"><div id="sidebar-nav-assessment" class="sidebar-secondary-nav">Assessment</div></a>
					<a href="#rewards"><div id="sidebar-nav-rewards" class="sidebar-secondary-nav">Rewards</div></a>
					<a href="#result"><div id="sidebar-nav-result" class="sidebar-secondary-nav">Result</div></a>-->
				</div>
			</div> <!-- /sidebar -->
			<div id="loading">Loading...</div>
			<div id="shadow"></div>
			<div id="main-container">
				<noscript>
					<p>Your browser does not support JavaScript or JavaScript terminated.</p>
					<p>Since your browser does not support JavaScript Or has been disabled JavaScript, Therefore, we can not display the requested page.</p>
				</noscript>
				<div id="main-content">
				</div> <!-- /main-content -->
				<?php
					require_once APPPATH.'views/common/footer.php';
				?>
			</div> <!-- /main-content -->
		</div> <!-- /content -->
	</div> <!-- /container -->
	<!-- Java Script -->
	<!-- Start of StatCounter Code for Default Guide -->
<script type="text/javascript">
var sc_project=11348767; 
var sc_invisible=1; 
var sc_security="50732d3c"; 
var scJsHost = (("https:" == document.location.protocol) ?
"https://secure." : "http://www.");
document.write("<sc"+"ript type='text/javascript' src='" +
scJsHost+
"statcounter.com/counter/counter.js'></"+"script>");
</script>
<noscript><div class="statcounter"><a title="web analytics"
href="http://statcounter.com/" target="_blank"><img
class="statcounter"
src="//c.statcounter.com/11348767/0/50732d3c/1/" alt="web
analytics"></a></div></noscript>
<!-- End of StatCounter Code for Default Guide -->
	<!-- Placed at the end of the document so the pages load faster -->
	<script type="text/javascript">
		$(document).ready(function() {
			$(window).resize(function() {
				set_footer_position();
			});
			$('#main-container').scroll(function() {
				if ( $('#main-content').position().top < 0 ) {
					$('#shadow').css('opacity', 1);
				} else {
					$('#shadow').css('opacity', 0);
				}
			});
		});
	</script> 
	<script type="text/javascript">
		$(document).ready(function() {
			var page_name = window.location.href.match(/#.*$/);
			if ( page_name == null ) {
				load('welcome');
			} else {
				load(window.location.href.match(/#.*$/)[0].substr(1));
			}
		});
	</script> 
	<script type="text/javascript">
		if ( ("onhashchange" in window) && !navigator.userAgent.toLowerCase().match(/msie/) ) {
			$(window).on('hashchange', function() {
				set_loading_block(true, true);
				load(window.location.href.match(/#.*$/)[0].substr(1));
			});
		} else {
			var prevHash = window.location.hash;
	        window.setInterval(function () {
	           if (window.location.hash != prevHash) {
	              prevHash = window.location.hash;
	              set_loading_block(true, true);
	              load(window.location.href.match(/#.*$/)[0].substr(1));
	           }
	        }, 100);
		}
	</script>
	<script type="text/javascript">
		function load(page){
			$('.active').removeClass('active');
			var sidebar_nav = $('#sidebar-nav-' + page);
			sidebar_nav.addClass('active');
			sidebar_nav.closest('.sidebar-nav').children().children('.sidebar-secondary-nav').slideDown(0);
			$.ajax( {
				type: 'GET',
				url: "<?php echo base_url(); ?>" + 'admin/load/' + page,
				cache: false,
				async: false,
				error: function() {
					set_loading_block(false, true);
				}, // End of error function of ajax form
				success: function(html_content) {
					if ( html_content != '' ) {
						$("#main-content").html(html_content);
						set_loading_block(true, false);
					} else {
						set_loading_block(false, true);
					}
					set_footer_position();
				} // End of success function of ajax form
			}); // End of ajax call
		}
	</script>
	<script type="text/javascript">
		function set_loading_block(is_success, is_visible) {
			if ( is_success ) {
				$('#loading').removeClass('error');
				$('#loading').addClass('loading');
				$('#loading').html('Loading...');
			} else {
				$('#loading').removeClass('loading');
				$('#loading').addClass('error');
				$("#main-content").html('');
				var page = window.location.href.match(/#.*$/)[0].substr(1);
				$('#loading').html('Error loading page please <a href="#' + page + 
									'" onclick="javascript:set_loading_block(' + true + ', ' + true + '); ' + 
									'javascript:load(\'' + page + '\');' + ' return false;">Retry</a>');
			}

			if ( is_visible ) {
				$('#loading').fadeIn();
			} else {
				$('#loading').css('display', 'none');
			}
		}
	</script>
	<script type="text/javascript">
		function set_footer_position() {
			$('#footer').css('position', 'relative');
			if ( $('#footer').position().top + 144 < $(document).height() ) {
				$('#footer').css('position', 'absolute');
			} else {
				$('#footer').css('position', 'relative');
			}
		}
	</script>
	<script type="text/javascript">
		$('.sidebar-primary-nav').click(function() {
			var secondary_nav_items = $(this).closest('.sidebar-nav').children().children('.sidebar-secondary-nav');
			if ( secondary_nav_items.is(':visible') ) {
				secondary_nav_items.slideUp(120);
			} else {
				secondary_nav_items.slideDown(120);
			}
		});
	</script>
</body>
</html>
