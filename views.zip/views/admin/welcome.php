<div id="welcome-center-header" class="page-header">
	<h1>
welcome</h1>
</div> <!-- /welcome-center-header -->
<div id="welcome-center-section" class="section">
	<p><strong><?php echo $welcome['display_name']; ?></strong> 
Welcome to Evangel University Management Information System.</p>
	<p>
Your IP address: <strong><?php echo $welcome['ip_address']; ?> | For Security Reasons <?php
		if ( $welcome['ip_address'] == '::1' ) {
			echo '
You are  on a localhost ip Configuration.';
}
	?>.</strong>.</p>

	<p><?php
		if ( $welcome['last_time_signin'] == '0000-00-00 00:00:00' ) {
			echo '
This is the first time you use this system , you can click<a href="'.base_url().'home#profile">
Here</a>
Edit your password.';	
		} else {
			$time = strtotime($welcome['last_time_signin']);
			echo 'Last access time: <strong>'.date('Y  m  d  H:i',$time).'</strong>';
		}
	?></p>
</div> <!-- /welcome-center-section -->

<div id="dashboard-header" class="page-header">
	<h1>
System Overview</h1>
</div> <!-- /accounts-header -->
<div id="dashboard-section" class="section">
	<table class="table" style="width: 84%;">
		
	</table>
</div> <!-- /accounts-section -->